package com.rango.companion.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RoundDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRound(round: RoundEntity)

    @Query("SELECT * FROM rounds ORDER BY timestamp DESC")
    fun getAllRounds(): Flow<List<RoundEntity>>

    @Query("SELECT * FROM rounds ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentRounds(limit: Int = 20): List<RoundEntity>

    @Query("SELECT COUNT(*) FROM rounds WHERE multiplier >= 2.0")
    suspend fun getWinCount(): Int

    @Query("SELECT COUNT(*) FROM rounds WHERE multiplier < 1.3")
    suspend fun getColdCrashCount(): Int

    @Query("SELECT COUNT(*) FROM rounds")
    suspend fun getTotalRounds(): Int

    @Query("SELECT SUM(profitLoss) FROM rounds")
    suspend fun getTotalProfitLoss(): Float?

    @Query("SELECT MAX(multiplier) FROM rounds")
    suspend fun getMaxMultiplier(): Float?

    @Query("DELETE FROM rounds")
    suspend fun clearAll()

    @Query("DELETE FROM rounds WHERE id = :id")
    suspend fun deleteRound(id: Int)
}
