package com.rango.companion.prediction

import com.rango.companion.data.RoundEntity
import kotlin.math.*

data class Prediction(
    val nextMultiplier: Float,
    val confidence: Int,
    val cashoutTarget: Float,
    val minCashout: Float,
    val maxCashout: Float,
    val signal: String,
    val signalColor: Long,
    val betMultiplier: Float,
    val reasoning: String,
    val streakType: String,
    val trend: String
)

object PredictionEngine {

    fun predict(rounds: List<RoundEntity>): Prediction {
        if (rounds.isEmpty()) return defaultPrediction()

        val values = rounds.map { it.multiplier }
        val recent5 = values.take(5)
        val recent10 = values.take(10)
        val recent20 = values.take(20)

        // Pattern analysis
        val avg20 = if (recent20.isNotEmpty()) recent20.average().toFloat() else 2f
        val avg10 = if (recent10.isNotEmpty()) recent10.average().toFloat() else 2f
        val avg5 = if (recent5.isNotEmpty()) recent5.average().toFloat() else 2f

        // Crash streak (consecutive < 1.5x)
        var crashStreak = 0
        for (v in values) {
            if (v < 1.5f) crashStreak++ else break
        }

        // Soar streak (consecutive >= 2x)
        var soarStreak = 0
        for (v in values) {
            if (v >= 2f) soarStreak++ else break
        }

        // Volatility
        val variance = if (recent20.size > 1) {
            val mean = recent20.average()
            recent20.map { (it - mean).pow(2) }.average().toFloat()
        } else 1f
        val volatility = sqrt(variance)

        // Cold percentage (last 10)
        val coldCount = recent10.count { it < 1.5f }
        val coldPct = if (recent10.isNotEmpty()) coldCount * 100 / recent10.size else 50

        // Momentum score: how trend is shifting
        val momentum = avg5 - avg10

        // Predicted next multiplier (pattern-weighted)
        val predicted: Float
        val signal: String
        val signalColor: Long
        val cashoutTarget: Float
        val confidence: Int
        val reasoning: StringBuilder = StringBuilder()

        when {
            // After 3+ crashes — reversal likely
            crashStreak >= 3 -> {
                predicted = (avg20 * 0.7f + 1.8f * 0.3f).coerceIn(1.3f, 5f)
                cashoutTarget = max(predicted * 0.75f, 1.5f)
                confidence = 72
                signal = "🔥 REVERSAL EXPECTED"
                signalColor = 0xFF00FF88
                reasoning.append("$crashStreak consecutive crashes detected. Reversal probability high. Safe cashout at ${String.format("%.1f", cashoutTarget)}x.")
            }
            // After 4+ soars — cooldown likely
            soarStreak >= 4 -> {
                predicted = (avg20 * 0.5f + 1.2f * 0.5f).coerceIn(1.1f, 2.5f)
                cashoutTarget = max(predicted * 0.8f, 1.3f)
                confidence = 68
                signal = "⚠ COOLDOWN INCOMING"
                signalColor = 0xFFFF5252
                reasoning.append("$soarStreak high rounds in a row. Game likely cooling down. Cashout EARLY at ${String.format("%.1f", cashoutTarget)}x.")
            }
            // Cold market (>60% crashes in last 10)
            coldPct >= 60 -> {
                predicted = 1.4f
                cashoutTarget = 1.3f
                confidence = 65
                signal = "🧊 COLD MARKET — CAUTION"
                signalColor = 0xFF64B5F6
                reasoning.append("${coldPct}% of last 10 rounds were below 1.5x. Cold streak active. Minimum bets only.")
            }
            // Positive momentum
            momentum > 0.5f -> {
                predicted = (avg5 * 0.8f + avg20 * 0.2f).coerceIn(1.5f, 8f)
                cashoutTarget = max(predicted * 0.7f, 1.5f)
                confidence = 70
                signal = "🚀 RISING MOMENTUM"
                signalColor = 0xFF69F0AE
                reasoning.append("Upward trend detected. Avg rising from ${String.format("%.2f", avg10)}x to ${String.format("%.2f", avg5)}x. Ride momentum to ${String.format("%.1f", cashoutTarget)}x.")
            }
            // Negative momentum
            momentum < -0.5f -> {
                predicted = (avg5 * 0.6f + 1.5f * 0.4f).coerceIn(1.2f, 3f)
                cashoutTarget = max(predicted * 0.75f, 1.3f)
                confidence = 63
                signal = "📉 DOWNWARD TREND"
                signalColor = 0xFFFF8A65
                reasoning.append("Trend declining from ${String.format("%.2f", avg10)}x. Reduce bet size. Early exit at ${String.format("%.1f", cashoutTarget)}x.")
            }
            // Stable / neutral
            else -> {
                predicted = avg20.coerceIn(1.3f, 5f)
                cashoutTarget = max(predicted * 0.72f, 1.5f)
                confidence = 60
                signal = "⚖ NEUTRAL — STEADY BET"
                signalColor = 0xFFFFD740
                reasoning.append("Market neutral. Average at ${String.format("%.2f", avg20)}x. Standard strategy: cashout at ${String.format("%.1f", cashoutTarget)}x.")
            }
        }

        val minCashout = (cashoutTarget * 0.85f).coerceAtLeast(1.2f)
        val maxCashout = cashoutTarget * 1.4f
        val betMult = when {
            confidence >= 70 -> 1.5f
            confidence >= 65 -> 1.0f
            else -> 0.5f
        }
        val trend = when {
            momentum > 0.3f -> "↑ RISING"
            momentum < -0.3f -> "↓ FALLING"
            else -> "→ FLAT"
        }
        val streakType = when {
            crashStreak >= 3 -> "CRASH x$crashStreak"
            soarStreak >= 3 -> "SOAR x$soarStreak"
            else -> "MIXED"
        }

        return Prediction(
            nextMultiplier = predicted,
            confidence = confidence,
            cashoutTarget = cashoutTarget,
            minCashout = minCashout,
            maxCashout = maxCashout,
            signal = signal,
            signalColor = signalColor,
            betMultiplier = betMult,
            reasoning = reasoning.toString(),
            streakType = streakType,
            trend = trend
        )
    }

    private fun Double.pow(n: Int): Double = this.toDouble().pow(n.toDouble())

    private fun defaultPrediction() = Prediction(
        nextMultiplier = 1.8f,
        confidence = 50,
        cashoutTarget = 1.5f,
        minCashout = 1.3f,
        maxCashout = 2.2f,
        signal = "📊 ENTER ROUNDS TO PREDICT",
        signalColor = 0xFFAAAAAA,
        betMultiplier = 0.5f,
        reasoning = "Koi data nahi. Pehle kuch rounds add karein.",
        streakType = "N/A",
        trend = "→ FLAT"
    )
}
