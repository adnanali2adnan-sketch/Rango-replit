package com.rango.companion.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rango.companion.MainViewModel
import com.rango.companion.UiState

@Composable
fun GeminiScreen(viewModel: MainViewModel, state: UiState) {
    var apiKeyInput by remember(state.apiKey) { mutableStateOf(state.apiKey) }
    var balanceInput by remember(state.balance) { mutableStateOf(state.balance.toString()) }
    var manualMultiplier by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var savedMsg by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Gemini AI Cockpit", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Configure AI & analyze patterns", color = GreenAccent, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))

        // API Key Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("🔑 GEMINI API KEY", color = YellowAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    placeholder = { Text("AIza...", color = TextDim) },
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        TextButton(onClick = { showKey = !showKey }) {
                            Text(if (showKey) "Hide" else "Show", color = GreenAccent, fontSize = 11.sp)
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = GreenAccent, unfocusedBorderColor = TextDim
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Text("Get free key: aistudio.google.com", color = TextDim, fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        viewModel.saveApiKey(apiKeyInput.trim())
                        savedMsg = "✓ API Key saved!"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("SAVE API KEY", color = Color.Black, fontWeight = FontWeight.Bold)
                }
                if (savedMsg.isNotEmpty()) {
                    Text(savedMsg, color = GreenAccent, fontSize = 11.sp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Balance Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("💰 WALLET BALANCE", color = YellowAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = balanceInput,
                    onValueChange = { balanceInput = it },
                    placeholder = { Text("100.00", color = TextDim) },
                    prefix = { Text("$", color = GreenAccent) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = GreenAccent, unfocusedBorderColor = TextDim
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        val amt = balanceInput.toFloatOrNull() ?: return@Button
                        viewModel.saveBalance(amt)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2979FF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("UPDATE BALANCE", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Manual Round Entry
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("✏ MANUAL ROUND ENTRY", color = Color(0xFF64B5F6), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Round ka multiplier enter karein (e.g. 1.85, 4.20)", color = TextDim, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = manualMultiplier,
                        onValueChange = { manualMultiplier = it },
                        placeholder = { Text("1.00x", color = TextDim) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF64B5F6), unfocusedBorderColor = TextDim
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            val m = manualMultiplier.toFloatOrNull() ?: return@Button
                            viewModel.addRound(m, "MANUAL")
                            manualMultiplier = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF64B5F6))
                    ) {
                        Text("ADD", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // AI Analysis
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⚡", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("LIVE GEMINI AI ANALYSIS", color = YellowAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text("Last ${minOf(state.rounds.size, 20)} rounds analyze ho jayenge", color = TextDim, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { viewModel.runGeminiAnalysis() },
                    enabled = !state.isAnalyzing && state.apiKey.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = YellowAccent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (state.isAnalyzing) {
                        CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
                    } else {
                        Text("🔮 ANALYZE WITH GEMINI AI", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
                if (state.apiKey.isBlank()) {
                    Text("⚠ Pehle API key save karein", color = RedAccent, fontSize = 11.sp)
                }
                if (state.aiResponse.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text("AI PREDICTION:", color = GreenAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0A1628), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(state.aiResponse, color = Color.White, fontSize = 12.sp, lineHeight = 20.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(80.dp))
    }
}
