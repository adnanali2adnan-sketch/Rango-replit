package com.rango.companion

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rango.companion.bankroll.BankrollCalculator
import com.rango.companion.bankroll.MartingaleStep
import com.rango.companion.data.AppDatabase
import com.rango.companion.data.RoundEntity
import com.rango.companion.gemini.GeminiRepository
import com.rango.companion.prediction.Prediction
import com.rango.companion.prediction.PredictionEngine
import com.rango.companion.prefs.PrefsManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
    val rounds: List<RoundEntity> = emptyList(),
    val apiKey: String = "",
    val balance: Float = 100f,
    val winRate: Float = 0f,
    val coldRate: Float = 0f,
    val totalPL: Float = 0f,
    val maxSoar: Float = 1f,
    val aiResponse: String = "",
    val isAnalyzing: Boolean = false,
    val baseBet: Float = 1f,
    val strategicBet: Float = 1f,
    val safeTarget: Float = 1.5f,
    val riskLabel: String = "LOW RISK",
    val stopLoss: Float = 15f,
    val dailyTarget: Float = 12f,
    val simulatorSteps: List<MartingaleStep> = emptyList(),
    val prediction: Prediction? = null,
    val consecutiveLosses: Int = 0
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)
    private val prefs = PrefsManager(app)
    private val gemini = GeminiRepository()

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            db.roundDao().getAllRounds().collect { rounds ->
                val total = rounds.size
                val wins = rounds.count { it.multiplier >= 2f }
                val cold = rounds.count { it.multiplier < 1.3f }
                val pl = rounds.sumOf { it.profitLoss.toDouble() }.toFloat()
                val max = rounds.maxOfOrNull { it.multiplier } ?: 1f
                val balance = _state.value.balance
                val losses = _state.value.consecutiveLosses
                val bankroll = BankrollCalculator.calculate(balance, rounds.take(20).map { it.multiplier }, losses)
                val prediction = PredictionEngine.predict(rounds)

                _state.update {
                    it.copy(
                        rounds = rounds,
                        winRate = if (total > 0) wins * 100f / total else 0f,
                        coldRate = if (total > 0) cold * 100f / total else 0f,
                        totalPL = pl,
                        maxSoar = max,
                        baseBet = bankroll.baseBet,
                        strategicBet = bankroll.strategicBet,
                        safeTarget = bankroll.safeTargetCashout,
                        riskLabel = bankroll.riskLabel,
                        stopLoss = bankroll.stopLoss,
                        dailyTarget = bankroll.dailyTarget,
                        prediction = prediction
                    )
                }
            }
        }
        viewModelScope.launch { prefs.apiKey.collect { key -> _state.update { it.copy(apiKey = key) } } }
        viewModelScope.launch { prefs.balance.collect { bal -> _state.update { it.copy(balance = bal) } } }
    }

    fun saveApiKey(key: String) = viewModelScope.launch { prefs.saveApiKey(key) }

    fun saveBalance(amount: Float) = viewModelScope.launch { prefs.saveBalance(amount) }

    fun addRound(multiplier: Float, source: String = "MANUAL") = viewModelScope.launch {
        db.roundDao().insertRound(RoundEntity(multiplier = multiplier, source = source))
    }

    fun clearAll() = viewModelScope.launch { db.roundDao().clearAll() }

    fun runGeminiAnalysis() = viewModelScope.launch {
        val key = _state.value.apiKey
        val recent = db.roundDao().getRecentRounds(20)
        _state.update { it.copy(isAnalyzing = true, aiResponse = "🔮 Analyzing...") }
        val result = gemini.analyzePrediction(key, recent, _state.value.balance, _state.value.baseBet)
        _state.update { it.copy(isAnalyzing = false, aiResponse = result) }
    }

    fun runSimulator(baseBet: Float, target: Float, steps: Int) {
        val result = BankrollCalculator.simulateMartingale(baseBet, target, steps)
        _state.update { it.copy(simulatorSteps = result) }
    }
}
