package com.rango.companion.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rounds")
data class RoundEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val multiplier: Float,
    val betAmount: Float = 0f,
    val profitLoss: Float = 0f,
    val source: String = "MANUAL",
    val timestamp: Long = System.currentTimeMillis()
)
