package com.rango.companion.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rango.companion.MainViewModel
import com.rango.companion.UiState

@Composable
fun SimulatorScreen(viewModel: MainViewModel, state: UiState) {
    var baseBetInput by remember { mutableStateOf("10") }
    var targetInput by remember { mutableStateOf("2.0") }
    var stepsInput by remember { mutableStateOf("5") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Strategy Simulator", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Martingale Steps Matrix", color = GreenAccent, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("📊 SIMULATOR SETTINGS", color = YellowAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))

                SimInput("Base Bet ($)", baseBetInput, { baseBetInput = it })
                Spacer(Modifier.height(8.dp))
                SimInput("Target Multiplier (e.g. 2.0)", targetInput, { targetInput = it })
                Spacer(Modifier.height(8.dp))
                SimInput("Survival Steps (3-10)", stepsInput, { stepsInput = it })
                Spacer(Modifier.height(12.dp))

                Button(
                    onClick = {
                        val base = baseBetInput.toFloatOrNull() ?: 10f
                        val target = targetInput.toFloatOrNull() ?: 2f
                        val steps = stepsInput.toIntOrNull()?.coerceIn(1, 10) ?: 5
                        viewModel.runSimulator(base, target, steps)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CALCULATE MATRIX", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (state.simulatorSteps.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("MARTINGALE MATRIX", color = YellowAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))

                    // Header
                    Row(Modifier.fillMaxWidth()) {
                        TableCell("Step", Color(0xFF64B5F6), Modifier.weight(0.5f))
                        TableCell("Bet", Color(0xFF64B5F6), Modifier.weight(1f))
                        TableCell("Total Risk", Color(0xFF64B5F6), Modifier.weight(1f))
                        TableCell("Win Profit", Color(0xFF64B5F6), Modifier.weight(1f))
                    }
                    Divider(color = TextDim, thickness = 0.5.dp)

                    state.simulatorSteps.forEachIndexed { index, step ->
                        val rowBg = if (index % 2 == 0) Color.Transparent else Color(0x11FFFFFF)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(rowBg)
                                .padding(vertical = 6.dp)
                        ) {
                            TableCell("#${step.step}", Color.White, Modifier.weight(0.5f))
                            TableCell("$${"%.2f".format(step.betAmount)}", YellowAccent, Modifier.weight(1f))
                            TableCell("$${"%.2f".format(step.totalRiskSoFar)}", RedAccent, Modifier.weight(1f))
                            TableCell("+$${"%.2f".format(step.netProfitIfWin)}", GreenAccent, Modifier.weight(1f))
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    val totalRisk = state.simulatorSteps.lastOrNull()?.totalRiskSoFar ?: 0f
                    Text("Total Capital Needed: $${"%.2f".format(totalRisk)}", color = RedAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Required Balance: $${"%.2f".format(totalRisk * 1.2f)} (with 20% buffer)",
                        color = TextDim, fontSize = 11.sp
                    )
                }
            }
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
fun SimInput(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label, color = TextDim, fontSize = 11.sp) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            focusedBorderColor = GreenAccent, unfocusedBorderColor = TextDim,
            focusedLabelColor = GreenAccent
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun TableCell(text: String, color: Color, modifier: Modifier) {
    Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = modifier.padding(horizontal = 4.dp))
}
