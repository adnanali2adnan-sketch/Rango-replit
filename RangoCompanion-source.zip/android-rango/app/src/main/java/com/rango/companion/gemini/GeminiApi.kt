package com.rango.companion.gemini

import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query

data class GeminiRequest(val contents: List<Content>)
data class Content(val parts: List<Part>)
data class Part(val text: String)
data class GeminiResponse(val candidates: List<Candidate>?)
data class Candidate(val content: Content?)

interface GeminiApi {
    // Primary: gemini-3.5-flash (latest fast model per architecture spec)
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse

    // Fallback 1: gemini-2.5-flash
    @POST("v1beta/models/gemini-2.5-flash:generateContent")
    suspend fun generateContent25(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse

    // Fallback 2: gemini-2.0-flash
    @POST("v1beta/models/gemini-2.0-flash:generateContent")
    suspend fun generateContent20(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse

    // Fallback 3: gemini-1.5-flash (always available on free tier)
    @POST("v1beta/models/gemini-1.5-flash:generateContent")
    suspend fun generateContentFallback(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}
