package com.rango.companion.gemini

import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query

data class GeminiRequest(val contents: List<Content>)
data class Content(val parts: List<Part>)
data class Part(val text: String)
data class GeminiResponse(val candidates: List<Candidate>?)
data class Candidate(val content: Content?)

interface GeminiApi {
    // gemini-2.0-flash — stable, free-tier compatible, works with all API keys
    // (Google markets this as "Gemini Flash" in AI Studio)
    @POST("v1beta/models/gemini-2.0-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse

    // Fallback: gemini-1.5-flash (older but always available on free tier)
    @POST("v1beta/models/gemini-1.5-flash:generateContent")
    suspend fun generateContentFallback(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}
