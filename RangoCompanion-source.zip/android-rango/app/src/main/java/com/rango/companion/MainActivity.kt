package com.rango.companion

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rango.companion.overlay.FloatingHudService
import com.rango.companion.ui.*

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var pendingHudStart = false

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            requestMediaProjection()
        } else {
            Toast.makeText(this, "Overlay permission required!", Toast.LENGTH_LONG).show()
        }
    }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            startHudService(result.resultCode, result.data!!)
        } else {
            Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            RangoApp(
                viewModel = viewModel,
                state = state,
                onActivateHud = { handleHudActivation() }
            )
        }
    }

    private fun handleHudActivation() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            overlayPermissionLauncher.launch(intent)
        } else {
            requestMediaProjection()
        }
    }

    private fun requestMediaProjection() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun startHudService(resultCode: Int, data: Intent) {
        val intent = Intent(this, FloatingHudService::class.java).apply {
            action = FloatingHudService.ACTION_START
            putExtra(FloatingHudService.EXTRA_RESULT_CODE, resultCode)
            putExtra(FloatingHudService.EXTRA_RESULT_DATA, data)
        }
        startForegroundService(intent)
        Toast.makeText(this, "HUD activated! Switch to Rango game.", Toast.LENGTH_SHORT).show()
        moveTaskToBack(true)
    }
}

@Composable
fun RangoApp(viewModel: MainViewModel, state: com.rango.companion.UiState, onActivateHud: () -> Unit) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Dashboard", "Gemini AI", "Simulator")

    Surface(modifier = Modifier.fillMaxSize(), color = BgDark) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0D0D1A))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    "RANGO COMPANION",
                    color = GreenAccent,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Content
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    0 -> DashboardScreen(viewModel, state, onActivateHud)
                    1 -> GeminiScreen(viewModel, state)
                    2 -> SimulatorScreen(viewModel, state)
                }
            }

            // Bottom nav
            NavigationBar(containerColor = Color(0xFF0D0D1A), tonalElevation = 0.dp) {
                tabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = {
                            Text(
                                when (index) { 0 -> "▦"; 1 -> "🧠"; else -> "📊" },
                                fontSize = 18.sp
                            )
                        },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = GreenAccent,
                            selectedTextColor = GreenAccent,
                            unselectedIconColor = TextDim,
                            unselectedTextColor = TextDim,
                            indicatorColor = Color(0xFF1A2A1A)
                        )
                    )
                }
            }
        }
    }
}
