package com.rango.companion.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rango.companion.MainViewModel
import com.rango.companion.UiState
import com.rango.companion.data.RoundEntity
import com.rango.companion.prediction.Prediction

val BgDark = Color(0xFF0D0D1A)
val GreenAccent = Color(0xFF00FF88)
val YellowAccent = Color(0xFFFFD740)
val RedAccent = Color(0xFFFF5252)
val CardBg = Color(0xFF151528)
val TextDim = Color(0xFFAAAAAA)

@Composable
fun DashboardScreen(viewModel: MainViewModel, state: UiState, onActivateHud: () -> Unit) {
    val context = LocalContext.current
    var showClearDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Rango Companion", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("AI Strategy Cockpit", color = GreenAccent, fontSize = 12.sp)
            }
            IconButton(onClick = { showClearDialog = true }) { Text("🗑", fontSize = 20.sp) }
        }

        Spacer(Modifier.height(12.dp))

        // ─── AI PREDICTION CARD (always on top) ─────────────────────────
        state.prediction?.let { pred ->
            PredictionCard(pred, state)
            Spacer(Modifier.height(12.dp))
        }

        // ─── Multiplier Ribbon ──────────────────────────────────────────
        if (state.rounds.isNotEmpty()) {
            Text("RECENT MULTIPLIERS", color = TextDim, fontSize = 10.sp)
            Spacer(Modifier.height(4.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(state.rounds.take(15)) { round -> MultiplierChip(round) }
            }
            Spacer(Modifier.height(12.dp))
        }

        // ─── HUD Control ────────────────────────────────────────────────
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🛩", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("COCKPIT HUD & SCREEN SCRAPER", color = GreenAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text("Game ke upar floating popup activate karo — drag karo, prediction dekho in-popup.", color = TextDim, fontSize = 11.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onActivateHud,
                        colors = ButtonDefaults.buttonColors(containerColor = GreenAccent),
                        modifier = Modifier.weight(1f)
                    ) { Text("▶ ACTIVATE HUD", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                            context.startActivity(intent)
                        },
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, GreenAccent)
                    ) { Text("AUTH OCR", color = GreenAccent, fontSize = 12.sp) }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ─── Stats Row ──────────────────────────────────────────────────
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            StatCard("WIN RATE\n(>=2x)", "${state.winRate.toInt()}%",
                "Avg: ${if (state.rounds.isEmpty()) "–" else "${"%.1f".format(state.rounds.map { it.multiplier }.average())}x"}",
                GreenAccent, Modifier.weight(1f))
            StatCard("COLD\n(<1.3x)", "${state.coldRate.toInt()}%",
                "Count: ${state.rounds.count { it.multiplier < 1.3f }}",
                Color(0xFF64B5F6), Modifier.weight(1f))
            StatCard("NET P/L", "${if (state.totalPL >= 0) "+" else ""}${"%.0f".format(state.totalPL)}",
                "Best: ${"%.1f".format(state.maxSoar)}x", YellowAccent, Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))

        // ─── Bankroll Card ──────────────────────────────────────────────
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("💼", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("SMART BANKROLL", color = YellowAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                BankRow("Balance", "$${"%.2f".format(state.balance)}", Color.White)
                BankRow("Risk Score", state.riskLabel, Color(android.graphics.Color.parseColor(
                    when (state.riskLabel) {
                        "EXTREME RISK" -> "#FF1744"
                        "HIGH RISK" -> "#FF5252"
                        "MEDIUM RISK" -> "#FFD740"
                        else -> "#00FF88"
                    }
                )))
                BankRow("Base Bet", "$${"%.2f".format(state.baseBet)}", GreenAccent)
                BankRow("Strategic Bet", "$${"%.2f".format(state.strategicBet)}", Color.White)
                BankRow("Safe Cashout", "${"%.1f".format(state.safeTarget)}x", GreenAccent)
                HorizontalDivider(color = Color(0x33FFFFFF), modifier = Modifier.padding(vertical = 6.dp))
                BankRow("Stop Loss", "$${"%.2f".format(state.stopLoss)}", RedAccent)
                BankRow("Daily Target", "+$${"%.2f".format(state.dailyTarget)}", GreenAccent)
            }
        }
        Spacer(Modifier.height(80.dp))
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear All Rounds?", color = Color.White) },
            text = { Text("Sab rounds delete ho jayenge.", color = TextDim) },
            confirmButton = {
                TextButton(onClick = { viewModel.clearAll(); showClearDialog = false }) {
                    Text("Delete", color = RedAccent)
                }
            },
            dismissButton = { TextButton(onClick = { showClearDialog = false }) { Text("Cancel", color = TextDim) } },
            containerColor = CardBg
        )
    }
}

@Composable
fun PredictionCard(pred: Prediction, state: UiState) {
    val signalColor = Color(pred.signalColor)
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1628)),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, signalColor.copy(alpha = 0.6f))
    ) {
        Column(Modifier.padding(16.dp)) {
            // Signal banner
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(signalColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(pred.signal, color = signalColor, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${pred.confidence}%", color = signalColor, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(10.dp))

            // Prediction grid
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PredBox("NEXT PRED", "${"%.2f".format(pred.nextMultiplier)}x", signalColor, Modifier.weight(1f))
                PredBox("CASHOUT AT", "${"%.1f".format(pred.cashoutTarget)}x", GreenAccent, Modifier.weight(1f))
                PredBox("MIN SAFE", "${"%.1f".format(pred.minCashout)}x", YellowAccent, Modifier.weight(1f))
            }

            Spacer(Modifier.height(8.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PredBox("BET x", "${"%.1f".format(pred.betMultiplier)}x base", Color(0xFF64B5F6), Modifier.weight(1f))
                PredBox("TREND", pred.trend, Color(0xFFCE93D8), Modifier.weight(1f))
                PredBox("STREAK", pred.streakType, Color(0xFFFFAB40), Modifier.weight(1f))
            }

            Spacer(Modifier.height(8.dp))

            // AI Reasoning
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0x11FFFFFF), RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(pred.reasoning, color = Color.White, fontSize = 11.sp, lineHeight = 18.sp)
            }

            // Cashout range bar
            Spacer(Modifier.height(8.dp))
            Text("CASHOUT RANGE", color = TextDim, fontSize = 9.sp)
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${"%.1f".format(pred.minCashout)}x", color = YellowAccent, fontSize = 10.sp)
                Box(
                    Modifier
                        .weight(1f)
                        .height(6.dp)
                        .padding(horizontal = 6.dp)
                        .background(Color(0x33FFFFFF), RoundedCornerShape(3.dp))
                ) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(0.6f)
                            .background(signalColor, RoundedCornerShape(3.dp))
                    )
                }
                Text("${"%.1f".format(pred.maxCashout)}x", color = GreenAccent, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun PredBox(label: String, value: String, color: Color, modifier: Modifier) {
    Box(
        modifier = modifier
            .background(color.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = TextDim, fontSize = 8.sp)
            Text(value, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MultiplierChip(round: RoundEntity) {
    val color = when {
        round.multiplier >= 10f -> Color(0xFFFF80AB)
        round.multiplier >= 4f -> Color(0xFFCE93D8)
        round.multiplier >= 2f -> Color(0xFF69F0AE)
        round.multiplier >= 1.5f -> Color(0xFFFFD740)
        else -> Color(0xFF78909C)
    }
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
            .border(1.dp, color, RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) { Text("${"%.2f".format(round.multiplier)}x", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun StatCard(label: String, value: String, sub: String, color: Color, modifier: Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(8.dp)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = TextDim, fontSize = 9.sp, textAlign = TextAlign.Center)
            Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = TextDim, fontSize = 9.sp)
        }
    }
}

@Composable
fun BankRow(label: String, value: String, valueColor: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextDim, fontSize = 11.sp)
        Text(value, color = valueColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
