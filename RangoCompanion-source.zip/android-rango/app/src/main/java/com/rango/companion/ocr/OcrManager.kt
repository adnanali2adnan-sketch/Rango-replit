package com.rango.companion.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class OcrManager(private val context: Context) {

    enum class GamePhase { BETTING, FLYING, CRASHED }

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var isRunning = false
    private val handler = Handler(Looper.getMainLooper())

    private var phase = GamePhase.BETTING
    private var currentFlyingValue = 1.00f
    private var lastLoggedValue = 0f
    private var roundLogged = false

    var onMultiplierDetected: ((Float) -> Unit)? = null
    var onStatusChange: ((String) -> Unit)? = null

    fun start(projection: MediaProjection) {
        if (isRunning) return
        mediaProjection = projection
        isRunning = true
        phase = GamePhase.BETTING
        roundLogged = false

        val metrics = context.resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val dpi = metrics.densityDpi

        // Use RGBA_8888 — we convert to ARGB_8888 before passing to ML Kit
        imageReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "RangoOCR", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, handler
        )

        onStatusChange?.invoke("OCR Active — Watching screen...")
        scheduleScan()
    }

    fun stop() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay = null; imageReader = null; mediaProjection = null
        onStatusChange?.invoke("OCR Stopped")
    }

    fun isActive() = isRunning

    private fun scheduleScan() {
        if (!isRunning) return
        handler.postDelayed({
            captureAndProcess()
            scheduleScan()
        }, 700)
    }

    private fun captureAndProcess() {
        var image: Image? = null
        try {
            image = imageReader?.acquireLatestImage() ?: return

            // ── Convert RGBA ImageReader frame → proper ARGB_8888 Bitmap ──────
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val w = image.width
            val h = image.height

            // Create ARGB_8888 bitmap with correct row width
            val rowWidth = rowStride / pixelStride
            val rawBitmap = Bitmap.createBitmap(rowWidth, h, Bitmap.Config.ARGB_8888)
            rawBitmap.copyPixelsFromBuffer(buffer)

            // If row padding exists, crop to actual width
            val fullBmp = if (rowWidth != w) {
                val cropped = Bitmap.createBitmap(rawBitmap, 0, 0, w, h)
                rawBitmap.recycle()
                cropped
            } else rawBitmap

            // ── Crop regions based on Rango game layout ───────────────────────
            // Multiplier area: y=12% → y=58% (where big number shows)
            val mainTop  = (h * 0.12f).toInt()
            val mainH    = (h * 0.46f).toInt().coerceAtMost(h - mainTop)

            // Ribbon area: y=5% → y=13% (small previous round pills)
            val ribTop   = (h * 0.05f).toInt()
            val ribH     = (h * 0.08f).toInt().coerceAtMost(h - ribTop)

            val mainBmp = Bitmap.createBitmap(fullBmp, 0, mainTop, w, mainH)
            val ribBmp  = Bitmap.createBitmap(fullBmp, 0, ribTop,  w, ribH)

            fullBmp.recycle()

            processFrame(mainBmp, ribBmp)
            // mainBmp and ribBmp recycled inside processFrame

        } catch (e: OutOfMemoryError) {
            onStatusChange?.invoke("Low memory — pausing scan")
        } catch (e: Exception) {
            // swallow — ML Kit failure is handled separately
        } finally {
            image?.close()
        }
    }

    private fun processFrame(mainBmp: Bitmap, ribBmp: Bitmap) {
        val mainImg = InputImage.fromBitmap(mainBmp, 0)

        recognizer.process(mainImg)
            .addOnSuccessListener { mainText ->
                mainBmp.recycle()
                val allText = mainText.text.uppercase()

                val isBetting = allText.contains("GETTING") || allText.contains("THE BETS") || allText.contains("NEXT ROUND")
                val isCrashed = allText.contains("FLEW AWAY") || allText.contains("FLEW") || allText.contains("AWAY")

                // Extract the biggest visible multiplier number
                val multiplierRegex = Regex("""(\d{1,3}[.,]\d{1,2})\s*[xX×]""")
                var bigValue = 0f
                var bigFontH = 0

                for (block in mainText.textBlocks) {
                    for (line in block.lines) {
                        val fh = line.boundingBox?.height() ?: 0
                        multiplierRegex.findAll(line.text).forEach { m ->
                            val v = m.groupValues[1].replace(",", ".").toFloatOrNull()
                            if (v != null && v in 1.01f..200f && fh > bigFontH) {
                                bigFontH = fh; bigValue = v
                            }
                        }
                    }
                }

                when {
                    isBetting -> {
                        if (phase == GamePhase.FLYING && !roundLogged && currentFlyingValue > 1.01f) {
                            roundLogged = true
                            lastLoggedValue = currentFlyingValue
                            onStatusChange?.invoke("💥 Round: PKR ${"%.2f".format(currentFlyingValue)}x (auto)")
                            onMultiplierDetected?.invoke(currentFlyingValue)
                        }
                        if (phase != GamePhase.BETTING) {
                            phase = GamePhase.BETTING
                            currentFlyingValue = 1.00f
                            onStatusChange?.invoke("⏳ Betting — place your bet!")
                        }
                        roundLogged = false
                        processRibbon(ribBmp)
                    }

                    isCrashed -> {
                        ribBmp.recycle()
                        if (!roundLogged) {
                            val final = if (bigValue > 1.00f) bigValue else currentFlyingValue
                            if (final > 1.00f) {
                                roundLogged = true
                                lastLoggedValue = final
                                phase = GamePhase.CRASHED
                                onStatusChange?.invoke("💥 CRASHED ${"%.2f".format(final)}x ✓ Logged!")
                                onMultiplierDetected?.invoke(final)
                            }
                        } else {
                            onStatusChange?.invoke("Crashed (${"%.2f".format(lastLoggedValue)}x) — next...")
                        }
                    }

                    bigValue > 1.00f -> {
                        ribBmp.recycle()
                        phase = GamePhase.FLYING
                        currentFlyingValue = bigValue
                        onStatusChange?.invoke("🛩 Flying: ${"%.2f".format(bigValue)}x")
                    }

                    else -> {
                        ribBmp.recycle()
                        if (phase == GamePhase.FLYING) onStatusChange?.invoke("🔍 Watching...")
                    }
                }
            }
            .addOnFailureListener { e ->
                mainBmp.recycle()
                ribBmp.recycle()
                onStatusChange?.invoke("Scan failed: ${e.message?.take(30) ?: "ML Kit error"}")
            }
    }

    private fun processRibbon(ribBmp: Bitmap) {
        val img = InputImage.fromBitmap(ribBmp, 0)
        recognizer.process(img)
            .addOnSuccessListener { text ->
                ribBmp.recycle()
                val regex = Regex("""(\d{1,3}[.,]\d{1,2})\s*[xX×]""")
                val vals = mutableListOf<Float>()
                for (block in text.textBlocks) {
                    for (line in block.lines) {
                        regex.findAll(line.text).forEach { m ->
                            m.groupValues[1].replace(",", ".").toFloatOrNull()
                                ?.takeIf { it in 1.01f..200f }
                                ?.let { vals.add(it) }
                        }
                    }
                }
                if (vals.size >= 3) {
                    onStatusChange?.invoke("Ribbon: ${vals.take(5).joinToString(" | ") { "${"%.2f".format(it)}x" }}")
                }
            }
            .addOnFailureListener { ribBmp.recycle() }
    }
}
