package com.rango.companion.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * Rango Game OCR — State Machine
 *
 * Game phases (from screenshots):
 *  BETTING  → "GETTING THE BETS" text visible, propeller spinning, no multiplier
 *  FLYING   → Rango on plane, big WHITE multiplier growing (1.06x → 4.50x…)
 *  CRASHED  → "FLEW AWAY!" text appears, big RED multiplier frozen (final result)
 *
 * Strategy:
 *  • Keep tracking the current in-flight multiplier (biggest number on screen)
 *  • When "FLEW AWAY" is detected → that scan's multiplier = FINAL ROUND RESULT → log it
 *  • After logging, wait until multiplier resets (≤ 1.05x or GETTING BETS) before next log
 *  • Read the top ribbon too for historical data (small coloured pills at top)
 */
class OcrManager(private val context: Context) {

    enum class GamePhase { BETTING, FLYING, CRASHED }

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var isRunning = false
    private val handler = Handler(Looper.getMainLooper())

    // State machine
    private var phase = GamePhase.BETTING
    private var currentFlyingValue = 1.00f
    private var lastLoggedValue = 0f
    private var roundLogged = false          // prevent duplicate logs per round

    var onMultiplierDetected: ((Float) -> Unit)? = null
    var onStatusChange: ((String) -> Unit)? = null

    // ─── START / STOP ────────────────────────────────────────────────────────

    fun start(projection: MediaProjection) {
        if (isRunning) return
        mediaProjection = projection
        isRunning = true
        phase = GamePhase.BETTING
        roundLogged = false

        val metrics = context.resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val dpi = metrics.densityDpi

        imageReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "RangoOCR", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, handler
        )

        onStatusChange?.invoke("OCR Active — Watching for rounds...")
        scheduleScan()
        onStatusChange?.invoke("OCR Active — Waiting for round...")
    }

    fun stop() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay = null; imageReader = null; mediaProjection = null
        onStatusChange?.invoke("OCR Stopped")
    }

    fun isActive() = isRunning

    // ─── SCAN LOOP ───────────────────────────────────────────────────────────

    private fun scheduleScan() {
        if (!isRunning) return
        handler.postDelayed({
            captureAndProcess()
            scheduleScan()
        }, 600)   // scan every 0.6 sec — catches crash moment reliably
    }

    private fun captureAndProcess() {
        val image = imageReader?.acquireLatestImage() ?: return
        try {
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * image.width

            val fullBmp = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height, Bitmap.Config.ARGB_8888
            )
            fullBmp.copyPixelsFromBuffer(buffer)

            val h = fullBmp.height
            val w = fullBmp.width

            // ── Region 1: Top ribbon (y=5%→13%) — previous rounds pills ──
            val ribbonTop = (h * 0.05f).toInt()
            val ribbonH   = (h * 0.08f).toInt()
            val ribbonBmp = Bitmap.createBitmap(fullBmp, 0, ribbonTop, w, ribbonH)

            // ── Region 2: Main multiplier area (y=12%→57%) ──────────────
            // Based on screenshots: multiplier takes up this vertical slice
            val mainTop = (h * 0.12f).toInt()
            val mainH   = (h * 0.45f).toInt()
            val mainBmp = Bitmap.createBitmap(fullBmp, 0, mainTop, w, mainH)

            processFrame(mainBmp, ribbonBmp)

            fullBmp.recycle(); ribbonBmp.recycle(); mainBmp.recycle()
        } catch (e: Exception) {
            onStatusChange?.invoke("Scan err: ${e.message?.take(25)}")
        } finally {
            image.close()
        }
    }

    // ─── PROCESS FRAME ───────────────────────────────────────────────────────

    private fun processFrame(mainBmp: Bitmap, ribbonBmp: Bitmap) {
        val mainImg = InputImage.fromBitmap(mainBmp, 0)
        recognizer.process(mainImg)
            .addOnSuccessListener { mainText ->
                val allText = mainText.text.uppercase()

                // ── Phase detection ──────────────────────────────────────
                val isBettingPhase = allText.contains("GETTING") ||
                                     allText.contains("BETS") ||
                                     allText.contains("NEXT ROUND")

                val isCrashedPhase = allText.contains("FLEW AWAY") ||
                                     allText.contains("FLEW") ||
                                     allText.contains("AWAY")

                // ── Extract big multiplier number ─────────────────────────
                // Pattern: digits + . + digits + x  (e.g. 8.81x, 1.06x, 9.80x)
                val multiplierRegex = Regex("""(\d{1,3}[.,]\d{1,2})\s*[xX×]""")
                var bigValue = 0f
                var bigFontSize = 0

                for (block in mainText.textBlocks) {
                    for (line in block.lines) {
                        val lineH = line.boundingBox?.height() ?: 0
                        val matches = multiplierRegex.findAll(line.text)
                        for (match in matches) {
                            val v = match.groupValues[1].replace(",", ".").toFloatOrNull()
                            if (v != null && v in 1.00f..200f && lineH > bigFontSize) {
                                bigFontSize = lineH
                                bigValue = v
                            }
                        }
                    }
                }

                // ── State machine transitions ─────────────────────────────
                when {

                    // ── Phase 1: BETTING ("GETTING THE BETS" on screen) ──────
                    isBettingPhase -> {
                        if (phase == GamePhase.FLYING && !roundLogged && currentFlyingValue > 1.01f) {
                            // Missed "FLEW AWAY!" — use last tracked flying value as fallback
                            roundLogged = true
                            lastLoggedValue = currentFlyingValue
                            onStatusChange?.invoke("💥 Round ended: ${"%.2f".format(currentFlyingValue)}x (fallback)")
                            onMultiplierDetected?.invoke(currentFlyingValue)
                        }
                        if (phase != GamePhase.BETTING) {
                            phase = GamePhase.BETTING
                            currentFlyingValue = 1.00f
                            onStatusChange?.invoke("⏳ Betting phase — place your bet!")
                        }
                        roundLogged = false
                    }

                    // ── Phase 2: CRASHED ("FLEW AWAY!" visible, RED number) ──
                    isCrashedPhase -> {
                        if (!roundLogged) {
                            // bigValue = RED number currently on screen (final crash value)
                            // fallback = last tracked flying value if OCR missed the number
                            val finalValue = when {
                                bigValue > 1.00f -> bigValue
                                currentFlyingValue > 1.01f -> currentFlyingValue
                                else -> 0f
                            }
                            if (finalValue > 1.00f) {
                                roundLogged = true
                                lastLoggedValue = finalValue
                                phase = GamePhase.CRASHED
                                onStatusChange?.invoke("💥 CRASHED at ${"%.2f".format(finalValue)}x ✓ Logged!")
                                onMultiplierDetected?.invoke(finalValue)
                            }
                        } else {
                            onStatusChange?.invoke("💥 Crashed (${"%.2f".format(lastLoggedValue)}x) — next round...")
                        }
                    }

                    // ── Phase 3: FLYING (number growing, plane in air) ───────
                    bigValue > 1.00f -> {
                        phase = GamePhase.FLYING
                        currentFlyingValue = bigValue
                        // Don't reset roundLogged here — only reset on BETTING phase
                        onStatusChange?.invoke("🛩 Flying: ${"%.2f".format(bigValue)}x — cashout?")
                    }

                    else -> {
                        if (phase == GamePhase.FLYING) {
                            onStatusChange?.invoke("🔍 Watching...")
                        }
                    }
                }

                // ── Also read ribbon for historical data ─────────────────
                // (process separately — don't block main flow)
                processRibbon(ribbonBmp)
            }
            .addOnFailureListener {
                onStatusChange?.invoke("ML Kit error — retrying")
            }
    }

    // ─── RIBBON READER (top row previous results) ────────────────────────────
    // Reads the small colored pills: "8.81x  9.80x  1.40x  1.08x  2.09x"
    // These are historical — only use to fill DB if DB is empty

    private fun processRibbon(ribbonBmp: Bitmap) {
        // Only run ribbon OCR if we're in betting phase (quiet time)
        if (phase != GamePhase.BETTING) return

        val ribbonImg = InputImage.fromBitmap(ribbonBmp, 0)
        recognizer.process(ribbonImg)
            .addOnSuccessListener { visionText ->
                val regex = Regex("""(\d{1,3}[.,]\d{1,2})\s*[xX×]""")
                val ribbonValues = mutableListOf<Float>()
                for (block in visionText.textBlocks) {
                    for (line in block.lines) {
                        regex.findAll(line.text).forEach { match ->
                            val v = match.groupValues[1].replace(",", ".").toFloatOrNull()
                            if (v != null && v in 1.00f..200f) ribbonValues.add(v)
                        }
                    }
                }
                // Note: ribbon values are reported separately
                // They are historical — caller can choose to import them
                if (ribbonValues.size >= 3) {
                    onStatusChange?.invoke("Ribbon: ${ribbonValues.take(5).joinToString(" | ") { "${"%.2f".format(it)}x" }}")
                }
            }
    }
}
