package com.rango.companion.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class OcrManager(private val context: Context) {

    enum class GamePhase { BETTING, FLYING, CRASHED }

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var isRunning = false
    private val handler = Handler(Looper.getMainLooper())

    private var phase = GamePhase.BETTING
    // Only grows during flight (game multiplier never goes backwards)
    private var peakFlyingValue = 1.00f
    private var lastLoggedValue = 0f
    private var roundLogged = false

    var onMultiplierDetected: ((Float) -> Unit)? = null
    var onStatusChange: ((String) -> Unit)? = null

    fun start(projection: MediaProjection) {
        if (isRunning) return
        mediaProjection = projection
        isRunning = true
        phase = GamePhase.BETTING
        roundLogged = false
        peakFlyingValue = 1.00f

        val metrics = context.resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val dpi = metrics.densityDpi

        imageReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "RangoOCR", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, handler
        )

        onStatusChange?.invoke("OCR Active — Watching screen...")
        scheduleScan()
    }

    fun stop() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay = null; imageReader = null; mediaProjection = null
        onStatusChange?.invoke("OCR Stopped")
    }

    fun isActive() = isRunning

    private fun scheduleScan() {
        if (!isRunning) return
        handler.postDelayed({ captureAndProcess(); scheduleScan() }, 700)
    }

    private fun captureAndProcess() {
        var image: Image? = null
        try {
            image = imageReader?.acquireLatestImage() ?: return

            val plane   = image.planes[0]
            val buffer  = plane.buffer
            val pStride = plane.pixelStride
            val rStride = plane.rowStride
            val w = image.width
            val h = image.height

            // Convert RGBA (ImageReader) → ARGB_8888 (ML Kit requirement)
            val rowWidth = rStride / pStride
            val rawBmp = Bitmap.createBitmap(rowWidth, h, Bitmap.Config.ARGB_8888)
            rawBmp.copyPixelsFromBuffer(buffer)
            val fullBmp = if (rowWidth != w) {
                val c = Bitmap.createBitmap(rawBmp, 0, 0, w, h)
                rawBmp.recycle(); c
            } else rawBmp

            // ─── CRITICAL: only scan TOP portion of screen (y=5%–50%) ────────
            // This EXCLUDES the HUD popup (sits at y≈55%+) which contains
            // "2.00x" in its prediction cells — that was polluting OCR results!
            val scanTop = (h * 0.05f).toInt()
            val scanH   = (h * 0.45f).toInt().coerceAtMost(h - scanTop)

            // Ribbon: very top row y=5%–12%
            val ribTop = scanTop
            val ribH   = (h * 0.07f).toInt().coerceAtMost(h - ribTop)

            // Main multiplier area: y=12%–50%
            val mainTop = (h * 0.12f).toInt()
            val mainH   = (h * 0.38f).toInt().coerceAtMost(h - mainTop)

            val mainBmp = Bitmap.createBitmap(fullBmp, 0, mainTop, w, mainH)
            val ribBmp  = Bitmap.createBitmap(fullBmp, 0, ribTop,  w, ribH)
            fullBmp.recycle()

            processFrame(mainBmp, ribBmp)
        } catch (e: OutOfMemoryError) {
            onStatusChange?.invoke("Low memory — scan paused")
        } catch (_: Exception) {
        } finally {
            image?.close()
        }
    }

    private fun processFrame(mainBmp: Bitmap, ribBmp: Bitmap) {
        val mainImg = InputImage.fromBitmap(mainBmp, 0)

        recognizer.process(mainImg)
            .addOnSuccessListener { visionText ->
                mainBmp.recycle()
                val allText = visionText.text.uppercase()

                val isBetting = allText.contains("GETTING") ||
                                allText.contains("THE BETS") ||
                                allText.contains("NEXT ROUND")
                val isCrashed = allText.contains("FLEW AWAY") ||
                                allText.contains("FLEW") && allText.contains("AWAY")

                // Find multiplier with LARGEST font — game number is always
                // far bigger than any overlay/popup text (min height 70px).
                val re = Regex("""(\d{1,3}[.,]\d{1,2})\s*[xX×]""")
                var bigValue  = 0f
                var bigFontH  = 0

                for (block in visionText.textBlocks) {
                    for (line in block.lines) {
                        val fh = line.boundingBox?.height() ?: 0
                        if (fh < 60) continue          // skip small popup text
                        re.findAll(line.text).forEach { m ->
                            val v = m.groupValues[1].replace(",", ".").toFloatOrNull()
                            if (v != null && v in 1.01f..200f && fh > bigFontH) {
                                bigFontH = fh; bigValue = v
                            }
                        }
                    }
                }

                when {
                    // ── BETTING phase ────────────────────────────────────────
                    isBetting -> {
                        // Save peak value from just-ended flight if not yet logged
                        if (phase == GamePhase.FLYING && !roundLogged && peakFlyingValue > 1.01f) {
                            roundLogged = true
                            lastLoggedValue = peakFlyingValue
                            onStatusChange?.invoke("💥 Round: ${"%.2f".format(peakFlyingValue)}x (auto-logged)")
                            onMultiplierDetected?.invoke(peakFlyingValue)
                        }
                        if (phase != GamePhase.BETTING) {
                            phase = GamePhase.BETTING
                            peakFlyingValue = 1.00f
                            onStatusChange?.invoke("⏳ Betting — place your bet!")
                        }
                        roundLogged = false
                        processRibbon(ribBmp)
                    }

                    // ── CRASHED ───────────────────────────────────────────────
                    isCrashed -> {
                        ribBmp.recycle()
                        if (!roundLogged) {
                            // Prefer the scanned number (if font is big enough),
                            // otherwise fall back to peakFlyingValue tracked during flight
                            val final = when {
                                bigValue > 1.00f && bigFontH >= 80 -> bigValue
                                peakFlyingValue > 1.00f            -> peakFlyingValue
                                bigValue > 1.00f                   -> bigValue
                                else                               -> 0f
                            }
                            if (final > 1.00f) {
                                roundLogged = true
                                lastLoggedValue = final
                                phase = GamePhase.CRASHED
                                onStatusChange?.invoke("💥 CRASHED ${"%.2f".format(final)}x ✓ Logged!")
                                onMultiplierDetected?.invoke(final)
                            }
                        } else {
                            onStatusChange?.invoke("Crashed (${"%.2f".format(lastLoggedValue)}x) — next...")
                        }
                    }

                    // ── FLYING — track PEAK (game number only goes up) ────────
                    bigValue > 1.00f && bigFontH >= 60 -> {
                        ribBmp.recycle()
                        phase = GamePhase.FLYING
                        // Only update peak — never go backwards
                        if (bigValue > peakFlyingValue) peakFlyingValue = bigValue
                        onStatusChange?.invoke("🛩 Flying: ${"%.2f".format(bigValue)}x")
                    }

                    else -> {
                        ribBmp.recycle()
                        if (phase == GamePhase.FLYING)
                            onStatusChange?.invoke("🔍 Scanning... (peak ${"%.2f".format(peakFlyingValue)}x)")
                    }
                }
            }
            .addOnFailureListener { e ->
                mainBmp.recycle()
                ribBmp.recycle()
                onStatusChange?.invoke("Scan err: ${e.message?.take(30) ?: "ML Kit"}")
            }
    }

    private fun processRibbon(ribBmp: Bitmap) {
        val img = InputImage.fromBitmap(ribBmp, 0)
        recognizer.process(img)
            .addOnSuccessListener { text ->
                ribBmp.recycle()
                val re = Regex("""(\d{1,3}[.,]\d{1,2})\s*[xX×]""")
                val vals = mutableListOf<Float>()
                for (block in text.textBlocks) {
                    for (line in block.lines) {
                        re.findAll(line.text).forEach { m ->
                            m.groupValues[1].replace(",", ".").toFloatOrNull()
                                ?.takeIf { it in 1.01f..200f }
                                ?.let { vals.add(it) }
                        }
                    }
                }
                if (vals.size >= 2)
                    onStatusChange?.invoke("Ribbon: ${vals.take(5).joinToString(" | ") { "${"%.2f".format(it)}x" }}")
            }
            .addOnFailureListener { ribBmp.recycle() }
    }
}
