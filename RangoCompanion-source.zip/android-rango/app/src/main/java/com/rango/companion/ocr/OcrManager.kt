package com.rango.companion.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper

class OcrManager(private val context: Context) {

    enum class GamePhase { BETTING, FLYING, CRASHED }

    private val recognizer = com.google.mlkit.vision.text.TextRecognition.getClient(
        com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS
    )
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var isRunning = false
    private val handler = Handler(Looper.getMainLooper())

    private var phase = GamePhase.BETTING
    private var peakFlyingValue = 1.00f
    private var lastLoggedValue = 0f
    private var roundLogged = false

    // Virtual display target dimensions
    private var vdW = 480
    private var vdH = 800
    private var lastOrientation = -1

    var onMultiplierDetected: ((Float) -> Unit)? = null
    var onStatusChange: ((String) -> Unit)? = null
    var getOverlayBounds: (() -> Rect?)? = null

    // ── Main regex: flying/crash multiplier — x suffix required ─────────────
    // IMPORTANT: x must be required so coin balance (e.g. "45.80") is NOT matched.
    // Balance has no "x", game multipliers always do (1.28x, 4.81x, etc.)
    private val multRe = Regex("""\b(\d{1,3}[.,]\d{1,2})\s*[xX×]""", RegexOption.IGNORE_CASE)

    // ── Ribbon regex: same rule — x required ────────────────────────────────
    private val ribRe  = Regex("""\b(\d{1,3}[.,]\d{1,2})\s*[xX×]""", RegexOption.IGNORE_CASE)

    fun start(projection: MediaProjection) {
        if (isRunning) return
        mediaProjection = projection
        isRunning = true
        phase = GamePhase.BETTING
        roundLogged = false
        peakFlyingValue = 1.00f

        val metrics = context.resources.displayMetrics
        lastOrientation = context.resources.configuration.orientation
        if (metrics.widthPixels > metrics.heightPixels) { vdW = 800; vdH = 480 }
        else { vdW = 480; vdH = 800 }

        setupVirtualDisplay()
        onStatusChange?.invoke("OCR Active — Watching screen...")
        scheduleScan()
    }

    private fun setupVirtualDisplay() {
        virtualDisplay?.release()
        imageReader?.close()
        imageReader = ImageReader.newInstance(vdW, vdH, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "RangoOCR", vdW, vdH, context.resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, handler
        )
    }

    fun stop() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay = null; imageReader = null; mediaProjection = null
        onStatusChange?.invoke("OCR Stopped")
    }

    fun isActive() = isRunning

    private fun scheduleScan() {
        if (!isRunning) return
        // FAST scan during flight (500ms) — catches rapid multiplier jumps before crash
        // RELAXED during betting (1200ms) — saves battery while waiting for next round
        val delay = when (phase) {
            GamePhase.FLYING  -> 500L
            else              -> 1200L
        }
        handler.postDelayed({
            checkOrientationChange()
            captureAndProcess()
            scheduleScan()
        }, delay)
    }

    private fun checkOrientationChange() {
        val newOrientation = context.resources.configuration.orientation
        if (newOrientation != lastOrientation) {
            lastOrientation = newOrientation
            val metrics = context.resources.displayMetrics
            if (metrics.widthPixels > metrics.heightPixels) { vdW = 800; vdH = 480 }
            else { vdW = 480; vdH = 800 }
            setupVirtualDisplay()
            onStatusChange?.invoke("Orientation changed — display reset")
        }
    }

    private fun captureAndProcess() {
        var image: Image? = null
        try {
            image = imageReader?.acquireLatestImage() ?: return

            val plane   = image.planes[0]
            val buffer  = plane.buffer
            val pStride = plane.pixelStride
            val rStride = plane.rowStride
            val w = image.width
            val h = image.height

            val rowWidth = rStride / pStride
            val rawBmp = Bitmap.createBitmap(rowWidth, h, Bitmap.Config.ARGB_8888)
            rawBmp.copyPixelsFromBuffer(buffer)
            val fullBmp = if (rowWidth != w) {
                val c = Bitmap.createBitmap(rawBmp, 0, 0, w, h); rawBmp.recycle(); c
            } else rawBmp

            // ── Overlay Masking: black box over HUD widget ────────────────
            val overlayBounds = getOverlayBounds?.invoke()
            if (overlayBounds != null) {
                val physW = context.resources.displayMetrics.widthPixels.toFloat()
                val physH = context.resources.displayMetrics.heightPixels.toFloat()
                val sx = w / physW; val sy = h / physH
                val canvas = Canvas(fullBmp)
                val paint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL }
                canvas.drawRect(
                    overlayBounds.left * sx, overlayBounds.top * sy,
                    overlayBounds.right * sx, overlayBounds.bottom * sy, paint
                )
            }

            // ── Crop regions ──────────────────────────────────────────────
            // MAIN multiplier area: skip left 3%, 94% width, y=11%→60%
            val mainCropL = (w * 0.03f).toInt()
            val mainCropW = (w * 0.94f).toInt().coerceAtMost(w - mainCropL)
            val mainTop   = (h * 0.11f).toInt()
            val mainH     = (h * 0.49f).toInt().coerceAtMost(h - mainTop)

            // RIBBON (history pill row): y=2%→11%
            //   Coin balance sits at x=0–25%, history pills start at x=25%+
            //   Skipping left 25% avoids reading balance (e.g. "45.80") as a round result
            val ribCropL  = (w * 0.25f).toInt()
            val ribCropW  = (w * 0.72f).toInt().coerceAtMost(w - ribCropL)
            val ribTop    = (h * 0.02f).toInt()
            val ribH      = (h * 0.09f).toInt().coerceAtMost(h - ribTop)

            val mainBmp = Bitmap.createBitmap(fullBmp, mainCropL, mainTop, mainCropW, mainH)
            val ribBmp  = Bitmap.createBitmap(fullBmp, ribCropL,  ribTop,  ribCropW,  ribH)
            fullBmp.recycle()

            processFrame(mainBmp, ribBmp)
        } catch (_: OutOfMemoryError) {
            onStatusChange?.invoke("Low memory — scan paused")
        } catch (_: Exception) {
        } finally {
            image?.close()
        }
    }

    private fun processFrame(mainBmp: Bitmap, ribBmp: Bitmap) {
        val mainImg = com.google.mlkit.vision.common.InputImage.fromBitmap(mainBmp, 0)

        recognizer.process(mainImg)
            .addOnSuccessListener { visionText ->
                mainBmp.recycle()
                val allText = visionText.text.uppercase()

                // Betting phase
                val isBetting = allText.contains("GETTING") ||
                                allText.contains("THE BETS") ||
                                allText.contains("NEXT ROUND")

                // Crash keywords (per game spec)
                val isCrashed = allText.contains("FLEW AWAY") ||
                                (allText.contains("FLEW") && allText.contains("AWAY")) ||
                                allText.contains("BURST") ||
                                allText.contains("CRASHED")

                // ── Find the LARGEST font multiplier on screen ────────────
                // During FLYING: min height 45px (lower = catches 1.00x, 1.10x)
                // During CRASH:  min height 35px (crash number in scale can be smaller)
                val minHeight = if (isCrashed) 35 else 45

                var bigValue  = 0f
                var bigFontH  = 0

                for (block in visionText.textBlocks) {
                    for (line in block.lines) {
                        val fh = line.boundingBox?.height() ?: 0
                        if (fh < minHeight) continue
                        multRe.findAll(line.text).forEach { m ->
                            val v = m.groupValues[1].replace(",", ".").toFloatOrNull()
                            if (v != null && v in 1.00f..200f && fh > bigFontH) {
                                bigFontH = fh; bigValue = v
                            }
                        }
                    }
                }

                when {
                    // ── BETTING ──────────────────────────────────────────────
                    isBetting -> {
                        if (phase == GamePhase.FLYING && !roundLogged && peakFlyingValue > 1.00f) {
                            roundLogged = true
                            lastLoggedValue = peakFlyingValue
                            onStatusChange?.invoke("💥 Round: ${"%.2f".format(peakFlyingValue)}x (auto-logged)")
                            onMultiplierDetected?.invoke(peakFlyingValue)
                        }
                        if (phase != GamePhase.BETTING) {
                            phase = GamePhase.BETTING
                            peakFlyingValue = 1.00f
                            onStatusChange?.invoke("⏳ Betting — place your bet!")
                        }
                        roundLogged = false
                        // Scan ribbon during betting to verify last round result
                        processRibbon(ribBmp)
                    }

                    // ── CRASHED ───────────────────────────────────────────────
                    isCrashed -> {
                        if (!roundLogged) {
                            // Preliminary value from main OCR scan:
                            // bigValue = large red crash number on screen (if readable)
                            // peakFlyingValue = highest flying value seen this round (may lag)
                            val preliminary = when {
                                bigValue >= 1.00f && bigFontH >= 35 -> bigValue
                                peakFlyingValue > 1.00f             -> peakFlyingValue
                                bigValue >= 1.00f                   -> bigValue
                                else                                -> 0f
                            }
                            if (preliminary >= 1.00f) {
                                roundLogged = true
                                lastLoggedValue = preliminary
                                phase = GamePhase.CRASHED
                                onStatusChange?.invoke("💥 CRASHED ~${"%.2f".format(preliminary)}x (verifying...)")
                                onMultiplierDetected?.invoke(preliminary)
                            }
                            // ── Ribbon scan at crash moment ───────────────────
                            // The ribbon IMMEDIATELY shows the just-crashed round's
                            // value as its first pill (e.g. "1.35x | 7.07x | ...").
                            // This is MORE accurate than peakFlyingValue (which lags)
                            // or OCR of crash number (which can misread red text).
                            processRibbon(ribBmp, fromCrash = true)
                        } else {
                            ribBmp.recycle()
                            onStatusChange?.invoke("Crashed (${"%.2f".format(lastLoggedValue)}x) — next...")
                        }
                    }

                    // ── FLYING ────────────────────────────────────────────────
                    bigValue >= 1.00f && bigFontH >= 45 -> {
                        ribBmp.recycle()
                        // New round transition: BETTING/CRASHED → FLYING
                        // MUST reset peak so old round's value doesn't carry over
                        // (e.g. last round peaked at 4.79x but new round starts at 1.04x)
                        if (phase != GamePhase.FLYING) {
                            peakFlyingValue = bigValue   // fresh start for this round
                        } else if (bigValue > peakFlyingValue) {
                            peakFlyingValue = bigValue   // track upward only within same round
                        }
                        phase = GamePhase.FLYING
                        onStatusChange?.invoke("🛩 Flying: ${"%.2f".format(bigValue)}x (peak ${"%.2f".format(peakFlyingValue)}x)")
                    }

                    else -> {
                        ribBmp.recycle()
                        if (phase == GamePhase.FLYING)
                            onStatusChange?.invoke("🔍 Scanning... (peak ${"%.2f".format(peakFlyingValue)}x)")
                    }
                }
            }
            .addOnFailureListener { e ->
                mainBmp.recycle()
                ribBmp.recycle()
                onStatusChange?.invoke("Scan err: ${e.message?.take(30) ?: "ML Kit"}")
            }
    }

    // ── Ribbon scan ───────────────────────────────────────────────────────────
    // fromCrash = true  → called at crash moment; ribbon first pill = actual crash value
    // fromCrash = false → called at betting phase; cross-checks logged value
    //
    // ribRe requires "x" suffix — coin balance (e.g. "53.80") is never matched.
    // Ribbon crop already skips left 25% of screen (balance area).
    private fun processRibbon(ribBmp: Bitmap, fromCrash: Boolean = false) {
        val img = com.google.mlkit.vision.common.InputImage.fromBitmap(ribBmp, 0)
        recognizer.process(img)
            .addOnSuccessListener { text ->
                ribBmp.recycle()
                val vals = mutableListOf<Float>()
                for (block in text.textBlocks) {
                    for (line in block.lines) {
                        ribRe.findAll(line.text).forEach { m ->
                            m.groupValues[1].replace(",", ".").toFloatOrNull()
                                ?.takeIf { it in 1.00f..500f }
                                ?.let { vals.add(it) }
                        }
                    }
                }
                if (vals.isEmpty()) return@addOnSuccessListener

                val ribbonFirst = vals.first()
                val ribbon = vals.take(5).joinToString(" | ") { "${"%.2f".format(it)}x" }

                if (fromCrash) {
                    // ── At crash moment: ribbon first pill is the authoritative result ──
                    // Overrides preliminary value (peakFlyingValue lag / OCR misread)
                    if (ribbonFirst >= 1.00f && ribbonFirst != lastLoggedValue) {
                        lastLoggedValue = ribbonFirst
                        onMultiplierDetected?.invoke(ribbonFirst)
                        onStatusChange?.invoke("💥 CRASHED ${"%.2f".format(ribbonFirst)}x ✓ (ribbon)")
                    } else {
                        onStatusChange?.invoke("💥 Crashed ${"%.2f".format(lastLoggedValue)}x ✓")
                    }
                } else {
                    // ── Betting phase: show ribbon + small-diff correction ─────────────
                    onStatusChange?.invoke("📊 Ribbon: $ribbon")
                    if (phase == GamePhase.BETTING &&
                        lastLoggedValue > 0f &&
                        ribbonFirst >= 1.00f &&
                        Math.abs(ribbonFirst - lastLoggedValue) > 0.05f) {
                        lastLoggedValue = ribbonFirst
                        onMultiplierDetected?.invoke(ribbonFirst)
                        onStatusChange?.invoke("🔄 Corrected: ${"%.2f".format(ribbonFirst)}x")
                    }
                }
            }
            .addOnFailureListener { ribBmp.recycle() }
    }
}
