package com.rango.companion.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class OcrManager(private val context: Context) {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var isRunning = false
    private val handler = Handler(Looper.getMainLooper())

    var onMultiplierDetected: ((Float) -> Unit)? = null
    var onStatusChange: ((String) -> Unit)? = null

    fun start(projection: MediaProjection) {
        if (isRunning) return
        mediaProjection = projection
        isRunning = true

        val metrics = context.resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "RangoOCR",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, handler
        )

        onStatusChange?.invoke("OCR Active - Scanning...")
        scheduleOcrScan()
    }

    private fun scheduleOcrScan() {
        if (!isRunning) return
        handler.postDelayed({
            captureAndProcess()
            scheduleOcrScan()
        }, 2000)
    }

    private fun captureAndProcess() {
        val image = imageReader?.acquireLatestImage() ?: return
        try {
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val bitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            // Crop top 20% where multiplier usually shows
            val croppedHeight = (bitmap.height * 0.25f).toInt()
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, croppedHeight)
            processWithMlKit(cropped)
            bitmap.recycle()
            cropped.recycle()
        } finally {
            image.close()
        }
    }

    private fun processWithMlKit(bitmap: Bitmap) {
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val multiplierRegex = Regex("""(\d+\.?\d*)[xX×]""")
                val numbers = mutableListOf<Float>()
                for (block in visionText.textBlocks) {
                    for (line in block.lines) {
                        val matches = multiplierRegex.findAll(line.text)
                        for (match in matches) {
                            val value = match.groupValues[1].toFloatOrNull()
                            if (value != null && value in 1.0f..200f) {
                                numbers.add(value)
                            }
                        }
                    }
                }
                if (numbers.isNotEmpty()) {
                    val highest = numbers.max()
                    onMultiplierDetected?.invoke(highest)
                }
            }
            .addOnFailureListener { /* silently ignore */ }
    }

    fun stop() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        onStatusChange?.invoke("OCR Stopped")
    }

    fun isActive() = isRunning
}
