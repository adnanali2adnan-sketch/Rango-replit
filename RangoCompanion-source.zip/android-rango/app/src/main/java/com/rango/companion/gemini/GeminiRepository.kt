package com.rango.companion.gemini

import com.rango.companion.data.RoundEntity
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

class GeminiRepository {

    private val api: GeminiApi by lazy {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.NONE }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
        Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GeminiApi::class.java)
    }

    // ── Waterfall: 3.5-flash → 2.5-flash → 2.0-flash → 1.5-flash ──────────
    private suspend fun callWithFallback(apiKey: String, req: GeminiRequest): String {
        // Try each model in order; fall through on 400/404 (model not found)
        val attempts: List<suspend () -> GeminiResponse> = listOf(
            { api.generateContent(apiKey = apiKey, request = req) },
            { api.generateContent25(apiKey = apiKey, request = req) },
            { api.generateContent20(apiKey = apiKey, request = req) },
            { api.generateContentFallback(apiKey = apiKey, request = req) }
        )

        var lastError = ""
        for (attempt in attempts) {
            try {
                val response = attempt()
                val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!text.isNullOrBlank()) return text
            } catch (e: HttpException) {
                when (e.code()) {
                    400, 404 -> { lastError = "model_not_found"; continue }
                    401, 403 -> return "❌ API key galat (${e.code()}) — Google AI Studio se sahi key copy karo"
                    429      -> return "⏳ Rate limit — 20 sec baad ↻ refresh dabao"
                    500, 503 -> return "❌ Gemini server down — baad mein try karo"
                    else     -> return "❌ HTTP ${e.code()}: ${e.message()?.take(60)}"
                }
            } catch (e: SocketTimeoutException) {
                return "⏳ Timeout — internet slow hai, dobara try karo"
            } catch (e: IOException) {
                return "❌ No internet — WiFi/data check karo"
            } catch (e: Exception) {
                return "❌ ${e.javaClass.simpleName}: ${e.message?.take(60) ?: "Unknown error"}"
            }
        }
        return "⚠ Koi bhi model respond nahi kiya. API key check karo."
    }

    // ── Deep analysis (called from Gemini tab) ─────────────────────────────
    suspend fun analyzePrediction(
        apiKey: String,
        recentRounds: List<RoundEntity>,
        balance: Float,
        baseBet: Float
    ): String {
        if (apiKey.isBlank()) return "⚠ API key missing. Gemini tab mein apni key enter karo."
        if (recentRounds.isEmpty()) return "📊 Koi rounds nahi. Pehle kuch rounds add karo."

        val seq = recentRounds.take(20).reversed().joinToString(", ") { "%.2fx".format(it.multiplier) }
        val last5 = recentRounds.take(5).map { it.multiplier }
        val coldCount = recentRounds.count { it.multiplier < 1.3f }
        val hotCount = recentRounds.count { it.multiplier >= 2.0f }
        val crashStreak = run { var s = 0; for (r in recentRounds) { if (r.multiplier < 1.5f) s++ else break }; s }
        val soarStreak = run { var s = 0; for (r in recentRounds) { if (r.multiplier >= 2f) s++ else break }; s }
        val avg = if (recentRounds.isNotEmpty()) recentRounds.map { it.multiplier }.average() else 0.0
        val last5Avg = if (last5.isNotEmpty()) last5.average() else 0.0

        val prompt = """
Act as a lightning-fast, high-accuracy math analytics processor for a crash game. Your target is a low-end display system, so your response must be extremely concise, direct, and stripped of unnecessary prose.

=== GAME DATA ===
Recent Multipliers (old→new): $seq
Total Rounds: ${recentRounds.size}
Last 5 Rounds: ${last5.joinToString(", ") { "%.2fx".format(it) }}
Overall Average: ${"%.2f".format(avg)}x
Last-5 Average: ${"%.2f".format(last5Avg)}x
Cold (<1.3x): $coldCount/${recentRounds.size}
Hot (≥2.0x): $hotCount/${recentRounds.size}
Crash Streak: $crashStreak rounds below 1.5x
Soar Streak: $soarStreak rounds above 2x

=== PLAYER INFO ===
Balance: PKR ${"%.0f".format(balance)}
Base Bet: PKR ${"%.0f".format(baseBet)}

Output Format (exactly 4 lines, no markdown, no extras):
RISK LEVEL: [LOW / MEDIUM / HIGH]
SUGGESTED BET: [PKR X.XX or SKIP]
SAFE CASHOUT: [X.XXx]
ANALYSIS: [1-sentence math explanation in simple mixed English/Urdu/Hindi]
        """.trimIndent()

        return callWithFallback(apiKey, GeminiRequest(listOf(Content(listOf(Part(prompt))))))
    }

    // ── Quick HUD prediction (called after every round, with 20s cooldown) ─
    suspend fun quickPrediction(
        apiKey: String,
        lastMultiplier: Float,
        recentRounds: List<RoundEntity>,
        balance: Float = 0f
    ): String {
        if (apiKey.isBlank()) return "API key add karo Gemini tab mein"

        val recent = recentRounds.take(10).reversed()
            .joinToString(", ") { "%.2fx".format(it.multiplier) }

        val prompt = """
Act as a lightning-fast, high-accuracy math analytics processor for a crash game. Your target is a low-end display system, so your response must be extremely concise, direct, and stripped of unnecessary prose.
Analyze the sequence of incoming multipliers provided: [$recent]
Current Balance is PKR ${"%.0f".format(balance)}.

Output Format Requirements (exactly 4 lines, no markdown, no backticks, no asterisks):
RISK LEVEL: [LOW / MEDIUM / HIGH]
SUGGESTED BET: [PKR X.XX or SKIP]
SAFE CASHOUT: [X.XXx]
ANALYSIS: [Provide a 1-sentence math explanation in very simple mixed English/Urdu/Hindi, e.g. "Cold streak chal raha hai, next 1.80x recovery chance high lag raha hai."]

Do not include any intro, header, backticks, asterisks, or conversational filler. Keep response strictly under 4 lines.
        """.trimIndent()

        return callWithFallback(apiKey, GeminiRequest(listOf(Content(listOf(Part(prompt))))))
    }
}
