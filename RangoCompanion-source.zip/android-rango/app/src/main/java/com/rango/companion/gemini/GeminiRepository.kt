package com.rango.companion.gemini

import com.rango.companion.data.RoundEntity
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class GeminiRepository {

    private val api: GeminiApi by lazy {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.NONE }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
        Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GeminiApi::class.java)
    }

    suspend fun analyzePrediction(
        apiKey: String,
        recentRounds: List<RoundEntity>,
        balance: Float,
        baseBet: Float
    ): String {
        if (apiKey.isBlank()) return "⚠ API key missing. Gemini tab mein enter karo."
        if (recentRounds.isEmpty()) return "📊 Koi rounds nahi. Pehle kuch rounds add karo."

        val seq = recentRounds.take(20).reversed().joinToString(", ") { "%.2fx".format(it.multiplier) }
        val last5 = recentRounds.take(5).map { it.multiplier }
        val coldCount = recentRounds.count { it.multiplier < 1.3f }
        val hotCount = recentRounds.count { it.multiplier >= 2.0f }
        val crashStreak = run { var s = 0; for (r in recentRounds) { if (r.multiplier < 1.5f) s++ else break }; s }
        val soarStreak = run { var s = 0; for (r in recentRounds) { if (r.multiplier >= 2f) s++ else break }; s }
        val avg = if (recentRounds.isNotEmpty()) recentRounds.map { it.multiplier }.average() else 0.0
        val last5Avg = if (last5.isNotEmpty()) last5.average() else 0.0

        val prompt = """
You are an expert Aviator/Crash game AI analyst. Analyze the data and give precise predictions.

=== GAME DATA ===
Recent Multipliers (old→new): $seq
Total Rounds Analyzed: ${recentRounds.size}
Last 5 Rounds: ${last5.joinToString(", ") { "%.2fx".format(it) }}

=== PATTERN STATS ===
Overall Average: ${"%.2f".format(avg)}x
Last-5 Average: ${"%.2f".format(last5Avg)}x
Cold Crashes (<1.3x): $coldCount/${recentRounds.size}
Hot Flights (≥2.0x): $hotCount/${recentRounds.size}
Current Crash Streak: $crashStreak consecutive rounds below 1.5x
Current Soar Streak: $soarStreak consecutive rounds above 2x

=== PLAYER INFO ===
Balance: ${"$"}${"%.2f".format(balance)}
Current Base Bet: ${"$"}${"%.2f".format(baseBet)}

=== REQUIRED OUTPUT (max 6 lines, Urdu+English mix ok) ===
SIGNAL: [one word: CRASH / CAUTION / NEUTRAL / BOOST / HOT]
NEXT PRED: [X.XXx to X.XXx range]
CASHOUT TARGET: [exact Xx]
MIN CASHOUT: [safe minimum Xx]  
BET SUGGESTION: ${"$"}[amount]
STRATEGY: [1 line bold advice in Urdu/English]

Be direct, no explanation. Just the 6 lines.
        """.trimIndent()

        return try {
            val response = api.generateContent(
                apiKey = apiKey,
                request = GeminiRequest(listOf(Content(listOf(Part(prompt)))))
            )
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "⚠ AI response nahi mila. Dobara try karo."
        } catch (e: Exception) {
            "❌ Error: ${e.message?.take(80) ?: "Network issue"}"
        }
    }

    suspend fun quickPrediction(
        apiKey: String,
        lastMultiplier: Float,
        recentRounds: List<RoundEntity>
    ): String {
        if (apiKey.isBlank()) return "API key add karo Gemini tab mein"
        val recent = recentRounds.take(5).map { "%.2fx".format(it.multiplier) }.joinToString(" → ")
        val prompt = """
Aviator game: Last round was ${"%.2f".format(lastMultiplier)}x. 
Recent 5: $recent
Give ONLY 2 lines:
1. CASHOUT: [X.Xx] 
2. SIGNAL: [one word advice]
        """.trimIndent()

        return try {
            val response = api.generateContent(
                apiKey = apiKey,
                request = GeminiRequest(listOf(Content(listOf(Part(prompt)))))
            )
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()
                ?: "Retry..."
        } catch (e: Exception) {
            "Network error"
        }
    }
}
