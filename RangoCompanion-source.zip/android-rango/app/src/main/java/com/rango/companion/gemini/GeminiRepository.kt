package com.rango.companion.gemini

import com.rango.companion.data.RoundEntity
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

class GeminiRepository {

    private val api: GeminiApi by lazy {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.NONE }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
        Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GeminiApi::class.java)
    }

    suspend fun analyzePrediction(
        apiKey: String,
        recentRounds: List<RoundEntity>,
        balance: Float,
        baseBet: Float
    ): String {
        if (apiKey.isBlank()) return "⚠ API key missing. Gemini tab mein apni key enter karo."
        if (recentRounds.isEmpty()) return "📊 Koi rounds nahi. Pehle kuch rounds add karo."

        val seq = recentRounds.take(20).reversed().joinToString(", ") { "%.2fx".format(it.multiplier) }
        val last5 = recentRounds.take(5).map { it.multiplier }
        val coldCount = recentRounds.count { it.multiplier < 1.3f }
        val hotCount = recentRounds.count { it.multiplier >= 2.0f }
        val crashStreak = run { var s = 0; for (r in recentRounds) { if (r.multiplier < 1.5f) s++ else break }; s }
        val soarStreak = run { var s = 0; for (r in recentRounds) { if (r.multiplier >= 2f) s++ else break }; s }
        val avg = if (recentRounds.isNotEmpty()) recentRounds.map { it.multiplier }.average() else 0.0
        val last5Avg = if (last5.isNotEmpty()) last5.average() else 0.0

        val prompt = """
You are an expert Aviator/Crash game AI analyst. Analyze the data and give precise predictions.

=== GAME DATA ===
Recent Multipliers (old→new): $seq
Total Rounds Analyzed: ${recentRounds.size}
Last 5 Rounds: ${last5.joinToString(", ") { "%.2fx".format(it) }}

=== PATTERN STATS ===
Overall Average: ${"%.2f".format(avg)}x
Last-5 Average: ${"%.2f".format(last5Avg)}x
Cold Crashes (<1.3x): $coldCount/${recentRounds.size}
Hot Flights (≥2.0x): $hotCount/${recentRounds.size}
Current Crash Streak: $crashStreak consecutive rounds below 1.5x
Current Soar Streak: $soarStreak consecutive rounds above 2x

=== PLAYER INFO ===
Balance: PKR ${"%.0f".format(balance)}
Current Base Bet: PKR ${"%.0f".format(baseBet)}

=== REQUIRED OUTPUT (max 6 lines, Urdu+English mix ok) ===
SIGNAL: [one word: CRASH / CAUTION / NEUTRAL / BOOST / HOT]
NEXT PRED: [X.XXx to X.XXx range]
CASHOUT TARGET: [exact Xx]
MIN CASHOUT: [safe minimum Xx]  
BET SUGGESTION: PKR [amount]
STRATEGY: [1 line bold advice in Urdu/English]

Be direct, no explanation. Just the 6 lines.
        """.trimIndent()

        val req = GeminiRequest(listOf(Content(listOf(Part(prompt)))))
        return try {
            // Primary: gemini-2.0-flash (free tier stable)
            val response = api.generateContent(apiKey = apiKey, request = req)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "⚠ AI response nahi mila. Dobara try karo."
        } catch (e: HttpException) {
            if (e.code() == 404 || e.code() == 400) {
                // Fallback: gemini-1.5-flash
                try {
                    val r2 = api.generateContentFallback(apiKey = apiKey, request = req)
                    r2.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                        ?: "⚠ AI response nahi mila."
                } catch (e2: HttpException) {
                    when (e2.code()) {
                        401, 403 -> "❌ API key galat (${e2.code()}) — AI Studio se sahi key copy karo"
                        429 -> "⏳ Rate limit — thodi der baad try karo"
                        else -> "❌ HTTP ${e2.code()} — API key check karo"
                    }
                } catch (_: Exception) {
                    "❌ No internet — WiFi/data check karo"
                }
            } else when (e.code()) {
                401, 403 -> "❌ API key galat (${e.code()}) — Google AI Studio se sahi key copy karo"
                429 -> "⏳ Rate limit — thodi der baad try karo"
                500, 503 -> "❌ Gemini server down — baad mein try karo"
                else -> "❌ HTTP ${e.code()}: ${e.message()?.take(60)}"
            }
        } catch (e: SocketTimeoutException) {
            "⏳ Timeout — internet slow hai, dobara try karo"
        } catch (e: IOException) {
            "❌ No internet — WiFi/data check karo"
        } catch (e: Exception) {
            "❌ ${e.javaClass.simpleName}: ${e.message?.take(60) ?: "Unknown error"}"
        }
    }

    suspend fun quickPrediction(
        apiKey: String,
        lastMultiplier: Float,
        recentRounds: List<RoundEntity>
    ): String {
        if (apiKey.isBlank()) return "API key add karo Gemini tab mein"
        val recent = recentRounds.take(5).map { "%.2fx".format(it.multiplier) }.joinToString(" → ")
        val prompt = """
Aviator game: Last round was ${"%.2f".format(lastMultiplier)}x. 
Recent 5: $recent
Give ONLY 2 lines:
1. CASHOUT: [X.Xx] 
2. SIGNAL: [one word advice]
        """.trimIndent()

        val req = GeminiRequest(listOf(Content(listOf(Part(prompt)))))
        return try {
            val response = api.generateContent(apiKey = apiKey, request = req)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()
                ?: "Retry..."
        } catch (e: HttpException) {
            if (e.code() == 404 || e.code() == 400) {
                try {
                    val r2 = api.generateContentFallback(apiKey = apiKey, request = req)
                    r2.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim() ?: "Retry..."
                } catch (_: Exception) { "No internet" }
            } else when (e.code()) {
                401, 403 -> "API key galat (${e.code()})"
                429 -> "Rate limit — wait karo"
                else -> "HTTP ${e.code()} error"
            }
        } catch (e: IOException) {
            "No internet"
        } catch (e: Exception) {
            "${e.javaClass.simpleName}: ${e.message?.take(40)}"
        }
    }
}
