package com.rango.companion.bankroll

import kotlin.math.*

data class BankrollResult(
    val baseBet: Float,
    val strategicBet: Float,
    val safeTargetCashout: Float,
    val riskLabel: String,
    val riskColor: Long,
    val recoveryStep: Int,
    val stopLoss: Float,
    val dailyTarget: Float
)

data class MartingaleStep(
    val step: Int,
    val betAmount: Float,
    val totalRiskSoFar: Float,
    val netProfitIfWin: Float
)

object BankrollCalculator {

    fun calculate(
        balance: Float,
        recentMultipliers: List<Float>,
        consecutiveLosses: Int = 0
    ): BankrollResult {
        val safeBase = (balance * 0.02f).coerceAtLeast(0.5f)

        val coldStreak = recentMultipliers.take(5).count { it < 1.5f }
        val avgMultiplier = if (recentMultipliers.isNotEmpty()) recentMultipliers.average().toFloat() else 2f

        val riskLevel = when {
            coldStreak >= 4 -> Triple("EXTREME RISK", 0xFFFF1744L, 1.3f)
            coldStreak >= 3 -> Triple("HIGH RISK", 0xFFFF5252L, 1.4f)
            coldStreak >= 2 || consecutiveLosses >= 3 -> Triple("MEDIUM RISK", 0xFFFFD740L, 1.5f)
            avgMultiplier >= 3f -> Triple("LOW RISK", 0xFF00FF88L, 1.8f)
            else -> Triple("LOW RISK", 0xFF69F0AEL, 1.5f)
        }

        val riskMultiplier = when (riskLevel.first) {
            "EXTREME RISK" -> 0.25f
            "HIGH RISK" -> 0.5f
            "MEDIUM RISK" -> 0.75f
            else -> 1.0f
        }

        val baseBet = (safeBase * riskMultiplier).coerceAtLeast(0.5f)

        val strategicBet = if (consecutiveLosses > 0) {
            (baseBet * 2f.pow(consecutiveLosses.toFloat())).coerceAtMost(balance * 0.1f)
        } else baseBet

        val stopLoss = balance * 0.15f
        val dailyTarget = balance * 0.12f

        return BankrollResult(
            baseBet = baseBet,
            strategicBet = strategicBet,
            safeTargetCashout = riskLevel.third,
            riskLabel = riskLevel.first,
            riskColor = riskLevel.second,
            recoveryStep = consecutiveLosses,
            stopLoss = stopLoss,
            dailyTarget = dailyTarget
        )
    }

    fun simulateMartingale(
        baseBet: Float,
        targetMultiplier: Float,
        steps: Int
    ): List<MartingaleStep> {
        val result = mutableListOf<MartingaleStep>()
        var totalRisk = 0f
        for (i in 1..steps) {
            val bet = baseBet * 2f.pow((i - 1).toFloat())
            totalRisk += bet
            val profit = bet * targetMultiplier - totalRisk
            result.add(MartingaleStep(i, bet, totalRisk, profit))
        }
        return result
    }

    private fun Float.pow(exp: Float): Float = Math.pow(this.toDouble(), exp.toDouble()).toFloat()
}
