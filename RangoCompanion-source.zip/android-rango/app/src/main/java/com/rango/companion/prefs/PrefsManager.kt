package com.rango.companion.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "rango_prefs")

class PrefsManager(private val context: Context) {

    companion object {
        private val API_KEY = stringPreferencesKey("gemini_api_key")
        private val BALANCE = floatPreferencesKey("wallet_balance")
    }

    val apiKey: Flow<String> = context.dataStore.data.map { it[API_KEY] ?: "" }
    val balance: Flow<Float> = context.dataStore.data.map { it[BALANCE] ?: 100f }

    suspend fun saveApiKey(key: String) {
        context.dataStore.edit { it[API_KEY] = key }
    }

    suspend fun saveBalance(amount: Float) {
        context.dataStore.edit { it[BALANCE] = amount }
    }
}
