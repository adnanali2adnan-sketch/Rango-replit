package com.rango.companion.prediction

enum class DtResult { DRAGON, TIGER, TIE }

data class DtPrediction(
    val suggestion: String,       // "DRAGON" | "TIGER" | "TIE" | "SKIP"
    val suggestionColor: Long,    // hex color
    val confidence: Int,          // 0-100
    val patternLabel: String,     // e.g. "Dragon Streak x4"
    val patternColor: Long,
    val reasoning: String,
    val lastResults: List<DtResult>
)

object DragonTigerEngine {

    fun analyze(results: List<DtResult>): DtPrediction {
        if (results.isEmpty()) return defaultPrediction()

        val recent = results.take(30)

        // ── Tie tracking: Tie IS recorded and factored in — never ignored ────
        // Tie is a DIFFERENT result from Dragon/Tiger, so it BREAKS the streak,
        // same as any other change of result. Example: D D Tie D = streak x1
        // (only the last D), NOT x3. Tie doesn't guarantee repeat OR reversal —
        // it's simply its own outcome, so streak counting uses the raw sequence.
        val dtOnlySeq = recent.filter { it != DtResult.TIE }
        val tieJustHappened = recent.first() == DtResult.TIE
        val tiesInLast5 = recent.take(5).count { it == DtResult.TIE }
        val tieNote = if (tieJustHappened) {
            "Tie abhi aayi hai — streak yahan se dobara shuru hogi. "
        } else if (tiesInLast5 >= 2) {
            "Last 5 mein $tiesInLast5 Tie aayi hain — streak count Tie ko bhi break point maan kar nikala gaya hai. "
        } else ""

        // ── Streak: count consecutive same result at head of RAW sequence ────
        // Tie counts as a break — it is not skipped over.
        val head = recent.first()
        var streakCount = 0
        if (head != DtResult.TIE) {
            for (r in recent) {
                if (r == head) streakCount++ else break
            }
        }

        // ── Alternating pattern: last 4+ D/T results alternate perfectly ────
        val altWindow = dtOnlySeq.take(6)
        val isAlternating = altWindow.size >= 4 && run {
            var alt = true
            for (i in 1 until altWindow.size) {
                if (altWindow[i] == altWindow[i - 1]) { alt = false; break }
            }
            alt
        }

        // ── Double pattern: DDTT DDTT style (pairs alternating), D/T sequence ─
        val isDoublePattern = dtOnlySeq.size >= 6 && run {
            val w = dtOnlySeq.take(6)
            w[0] == w[1] && w[2] == w[3] && w[4] == w[5] && w[0] != w[2] && w[2] != w[4] && w[0] == w[4]
        }

        // ── Hot side: which side (D/T only) won more in last 12, weighted toward recent ─
        val last12 = dtOnlySeq.take(12)
        val dragonCount = last12.count { it == DtResult.DRAGON }
        val tigerCount = last12.count { it == DtResult.TIGER }
        val hotSide = if (dragonCount >= tigerCount) DtResult.DRAGON else DtResult.TIGER
        val hotStrength = if (last12.isNotEmpty()) maxOf(dragonCount, tigerCount).toFloat() / last12.size else 0.5f

        // ── Decision logic — Tie overdue rule removed (Tie button stays manual-only) ─
        // Tie ke baad koi guaranteed repeat/reversal nahi maana jata — jab tak
        // Tie ke baad naya D/T streak khud nahi ban jata, hum sirf hot-side /
        // history se decide karte hain (neeche wala default branch handle karta hai).
        val suggestion: String
        val suggestionColor: Long
        val confidence: Int
        val patternLabel: String
        val patternColor: Long
        var reasoning: String

        when {
            // Strong streak (≥ 4), only valid when head itself is D/T (not Tie)
            streakCount >= 4 && head != DtResult.TIE -> {
                val opposite = if (head == DtResult.DRAGON) "TIGER" else "DRAGON"
                suggestion = opposite
                suggestionColor = if (opposite == "DRAGON") 0xFFEF5350 else 0xFF42A5F5
                confidence = minOf(70 + (streakCount - 4) * 3, 85)
                patternLabel = "${head.name} Streak x$streakCount"
                patternColor = 0xFFFF7043
                reasoning = "${head.name} $streakCount baar consecutive aaya. Reversal ka strong imkaan hai. $opposite par bet lagao."
            }

            // Medium streak (3) → consider opposite
            streakCount == 3 && head != DtResult.TIE -> {
                val opposite = if (head == DtResult.DRAGON) "TIGER" else "DRAGON"
                suggestion = opposite
                suggestionColor = if (opposite == "DRAGON") 0xFFEF5350 else 0xFF42A5F5
                confidence = 62
                patternLabel = "${head.name} Streak x3"
                patternColor = 0xFFFFAB40
                reasoning = "${head.name} 3 baar consecutive aaya. Reversal possible. Carefully $opposite try karo."
            }

            // Double-pair pattern (DDTT style) → predict next pair start
            isDoublePattern -> {
                val next = if (recent[0] == DtResult.DRAGON) "TIGER" else "DRAGON"
                suggestion = next
                suggestionColor = if (next == "DRAGON") 0xFFEF5350 else 0xFF42A5F5
                confidence = 66
                patternLabel = "⚡ Double Pattern (pairs)"
                patternColor = 0xFFBA68C8
                reasoning = "Game DD-TT jaisa pair pattern dikha raha hai. Agla $next expected hai."
            }

            // Alternating pattern → continue the pattern
            isAlternating -> {
                val nextInPattern = if (recent.first() == DtResult.DRAGON) "TIGER" else "DRAGON"
                suggestion = nextInPattern
                suggestionColor = if (nextInPattern == "DRAGON") 0xFFEF5350 else 0xFF42A5F5
                confidence = 65
                patternLabel = "↕ Alternating Pattern"
                patternColor = 0xFF80DEEA
                reasoning = "Game DRAGON-TIGER pattern mein chal raha hai. Pattern ke mutabiq agla $nextInPattern hoga."
            }

            // Hot side continuation, confidence scaled by how dominant the hot side is
            else -> {
                suggestion = hotSide.name
                suggestionColor = if (hotSide == DtResult.DRAGON) 0xFFEF5350 else 0xFF42A5F5
                confidence = (50 + hotStrength * 20).toInt().coerceIn(50, 65)
                patternLabel = "${hotSide.name} Hot (last ${last12.size})"
                patternColor = 0xFF69F0AE
                reasoning = "Last ${last12.size} mein ${if (hotSide == DtResult.DRAGON) dragonCount else tigerCount} baar ${hotSide.name} aaya. Hot side par bet karo."
            }
        }

        reasoning = tieNote + reasoning

        return DtPrediction(
            suggestion = suggestion,
            suggestionColor = suggestionColor,
            confidence = confidence,
            patternLabel = patternLabel,
            patternColor = patternColor,
            reasoning = reasoning,
            lastResults = recent.take(10)
        )
    }

    private fun defaultPrediction() = DtPrediction(
        suggestion = "–",
        suggestionColor = 0xFFAAAAAA,
        confidence = 0,
        patternLabel = "Data nahi",
        patternColor = 0xFFAAAAAA,
        reasoning = "Dragon, Tiger ya Tie button dabao — pattern analyze hoga.",
        lastResults = emptyList()
    )
}
