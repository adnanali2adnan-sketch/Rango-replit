package com.rango.companion.prediction

enum class DtResult { DRAGON, TIGER, TIE }

data class DtPrediction(
    val suggestion: String,       // "DRAGON" | "TIGER" | "TIE" | "SKIP"
    val suggestionColor: Long,    // hex color
    val confidence: Int,          // 0-100
    val patternLabel: String,     // e.g. "Dragon Streak x4"
    val patternColor: Long,
    val reasoning: String,
    val lastResults: List<DtResult>
)

object DragonTigerEngine {

    fun analyze(results: List<DtResult>): DtPrediction {
        if (results.isEmpty()) return defaultPrediction()

        val recent = results.take(30)

        // ── Streak: count consecutive same result at head ─────────────────
        val head = recent.first()
        var streakCount = 0
        for (r in recent) {
            if (r == head) streakCount++ else break
        }

        // ── Alternating pattern: last 4+ results alternate perfectly ──────
        val isAlternating = recent.size >= 4 && run {
            var alt = true
            for (i in 1 until minOf(6, recent.size)) {
                if (recent[i] == recent[i - 1]) { alt = false; break }
            }
            alt
        }

        // ── Tie analysis: how many rounds since last Tie ───────────────────
        var roundsSinceTie = 0
        for (r in recent) {
            if (r == DtResult.TIE) break
            roundsSinceTie++
        }

        // ── Hot side: which side (D/T only) won more in last 10 ──────────
        val last10 = recent.take(10).filter { it != DtResult.TIE }
        val dragonCount = last10.count { it == DtResult.DRAGON }
        val tigerCount = last10.count { it == DtResult.TIGER }
        val hotSide = if (dragonCount >= tigerCount) DtResult.DRAGON else DtResult.TIGER

        // ── Decision logic ────────────────────────────────────────────────
        val suggestion: String
        val suggestionColor: Long
        val confidence: Int
        val patternLabel: String
        val patternColor: Long
        val reasoning: String

        when {
            // Tie is overdue (≥ 10 rounds since last tie)
            roundsSinceTie >= 10 -> {
                suggestion = "TIE"
                suggestionColor = 0xFFFFD740
                confidence = 55
                patternLabel = "Tie Overdue ($roundsSinceTie rounds)"
                patternColor = 0xFFFFD740
                reasoning = "$roundsSinceTie rounds bina Tie ke guzar gaye. Tie aane ka waqt ho sakta hai. Chota bet lagao Tie par."
            }

            // Strong streak (≥ 4) → reversal likely
            streakCount >= 4 && head != DtResult.TIE -> {
                val opposite = if (head == DtResult.DRAGON) "TIGER" else "DRAGON"
                suggestion = opposite
                suggestionColor = if (opposite == "DRAGON") 0xFFEF5350 else 0xFF42A5F5
                confidence = 68
                patternLabel = "${head.name} Streak x$streakCount"
                patternColor = 0xFFFF7043
                reasoning = "${head.name} $streakCount baar aaya. Reversal ka imkaan zyada hai. $opposite par bet lagao."
            }

            // Medium streak (3) → consider opposite
            streakCount == 3 && head != DtResult.TIE -> {
                val opposite = if (head == DtResult.DRAGON) "TIGER" else "DRAGON"
                suggestion = opposite
                suggestionColor = if (opposite == "DRAGON") 0xFFEF5350 else 0xFF42A5F5
                confidence = 60
                patternLabel = "${head.name} Streak x3"
                patternColor = 0xFFFFAB40
                reasoning = "${head.name} 3 baar consecutive aaya. Reversal possible. Carefully $opposite try karo."
            }

            // Alternating pattern → continue the pattern
            isAlternating -> {
                val nextInPattern = if (recent.first() == DtResult.DRAGON) "TIGER" else "DRAGON"
                suggestion = nextInPattern
                suggestionColor = if (nextInPattern == "DRAGON") 0xFFEF5350 else 0xFF42A5F5
                confidence = 65
                patternLabel = "↕ Alternating Pattern"
                patternColor = 0xFF80DEEA
                reasoning = "Game DRAGON-TIGER pattern mein chal raha hai. Pattern ke mutabiq agla $nextInPattern hoga."
            }

            // Hot side continuation
            else -> {
                suggestion = hotSide.name
                suggestionColor = if (hotSide == DtResult.DRAGON) 0xFFEF5350 else 0xFF42A5F5
                confidence = 55
                patternLabel = "${hotSide.name} Hot (last 10)"
                patternColor = 0xFF69F0AE
                reasoning = "Last 10 mein ${if (hotSide == DtResult.DRAGON) dragonCount else tigerCount} baar ${hotSide.name} aaya. Hot side par bet karo."
            }
        }

        return DtPrediction(
            suggestion = suggestion,
            suggestionColor = suggestionColor,
            confidence = confidence,
            patternLabel = patternLabel,
            patternColor = patternColor,
            reasoning = reasoning,
            lastResults = recent.take(10)
        )
    }

    private fun defaultPrediction() = DtPrediction(
        suggestion = "–",
        suggestionColor = 0xFFAAAAAA,
        confidence = 0,
        patternLabel = "Data nahi",
        patternColor = 0xFFAAAAAA,
        reasoning = "Dragon, Tiger ya Tie button dabao — pattern analyze hoga.",
        lastResults = emptyList()
    )
}
