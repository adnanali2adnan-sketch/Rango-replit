package com.rango.companion.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.*
import android.text.InputType
import android.view.*
import android.widget.*
import com.rango.companion.bankroll.BankrollCalculator
import com.rango.companion.data.AppDatabase
import com.rango.companion.data.RoundEntity
import com.rango.companion.gemini.GeminiRepository
import com.rango.companion.ocr.OcrManager
import com.rango.companion.prediction.DragonTigerEngine
import com.rango.companion.prediction.DtResult
import com.rango.companion.prediction.PredictionEngine
import com.rango.companion.prefs.PrefsManager
import kotlinx.coroutines.*

class FloatingHudService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val CHANNEL_ID = "rango_hud_channel"
        const val NOTIF_ID = 101
        const val GEMINI_COOLDOWN_MS = 4_000L
        // SharedPreferences key for DT history persistence
        const val DT_PREFS = "dt_history_prefs"
        const val DT_PREFS_KEY = "dt_results"
    }

    private lateinit var windowManager: WindowManager
    private var hudView: View? = null
    private var ocrManager: OcrManager? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var db: AppDatabase
    private lateinit var prefsManager: PrefsManager
    private val geminiRepo = GeminiRepository()

    // State
    private var balance = 100f
    private var apiKey = ""
    private var isOcrRunning = false
    private var resultCode: Int = 0
    private var resultData: Intent? = null

    // 4-second Gemini cooldown guard
    private var lastGeminiCallTime = 0L

    // Game mode: "RANGO" or "DT"
    private var gameMode = "RANGO"

    // Dragon Tiger: in-memory result history
    private val dtResults = mutableListOf<DtResult>()

    // HUD Views — Rango
    private var layoutRango: LinearLayout? = null
    private var tvSignal: TextView? = null
    private var tvNextPred: TextView? = null
    private var tvCashout: TextView? = null
    private var tvMinCashout: TextView? = null
    private var tvBet: TextView? = null
    private var tvTrend: TextView? = null
    private var tvStreak: TextView? = null
    private var tvReasoning: TextView? = null
    private var tvGeminiResult: TextView? = null
    private var tvOcrStatus: TextView? = null
    private var tvBalance: TextView? = null
    private var tvRisk: TextView? = null
    private var tvRibbon: TextView? = null
    private var tvCooldownTimer: TextView? = null
    private var btnRefreshGemini: TextView? = null
    private var btnAutoOcr: Button? = null
    private var layoutAuto: LinearLayout? = null
    private var layoutManual: LinearLayout? = null
    private var etManualInput: EditText? = null
    private var btnAutoTab: TextView? = null
    private var btnManualTab: TextView? = null

    // HUD Views — Dragon Tiger
    private var layoutDT: LinearLayout? = null
    private var tvDtSuggestion: TextView? = null
    private var tvDtPattern: TextView? = null
    private var tvDtReasoning: TextView? = null
    private var tvDtHistory: TextView? = null
    private var tvDtConfidence: TextView? = null
    private var btnGameRango: TextView? = null
    private var btnGameDT: TextView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        db = AppDatabase.getInstance(this)
        prefsManager = PrefsManager(this)
        ocrManager = OcrManager(this)
        createNotificationChannel()
        loadDtHistory()   // restore DT history from last session
        scope.launch { prefsManager.apiKey.collect { apiKey = it } }
        scope.launch { prefsManager.balance.collect { balance = it; refreshUI() } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                @Suppress("DEPRECATION")
                resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA)
                startForeground(NOTIF_ID, buildNotification())
                showHud()
            }
            ACTION_STOP -> { stopHud(); stopSelf() }
        }
        return START_NOT_STICKY
    }

    // ─── HUD LAYOUT BUILD ───────────────────────────────────────────────────

    private fun showHud() {
        if (hudView != null) return
        val root = buildHudLayout()
        hudView = root
        val params = WindowManager.LayoutParams(
            650,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 120 }
        setupDrag(root, params)
        windowManager.addView(root, params)
        refreshUI()
    }

    private fun buildHudLayout(): LinearLayout {
        val ctx = this

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#EE0D1420"))
            setPadding(20, 14, 20, 14)
        }

        // ── Header ─────────────────────────────────────────────────────
        val hdr = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        hdr.addView(label(ctx, "⬡ RANGO PILOT", "#00FF88", 13f, true, 1f))
        hdr.addView(closeBtn(ctx))
        root.addView(hdr)
        root.addView(div(ctx))

        // ── Game Mode Tabs: RANGO | DRAGON TIGER ───────────────────────
        val gameTabs = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 6)
        }
        btnGameRango = TextView(ctx).apply {
            text = "⬡ RANGO"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#00FF88"))
            setPadding(14, 7, 14, 7); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
            setOnClickListener { switchGameMode("RANGO") }
        }
        btnGameDT = TextView(ctx).apply {
            text = "🐉 DRAGON TIGER"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#33FFFFFF"))
            setPadding(14, 7, 14, 7); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { switchGameMode("DT") }
        }
        gameTabs.addView(btnGameRango); gameTabs.addView(btnGameDT)
        root.addView(gameTabs)
        root.addView(div(ctx))

        // ── RANGO LAYOUT (hidden in DT mode) ────────────────────────────
        layoutRango = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val rango = layoutRango!!

        // ── SIGNAL banner ───────────────────────────────────────────────
        tvSignal = TextView(ctx).apply {
            text = "📊 ENTER ROUNDS TO PREDICT"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 6, 0, 6)
        }
        rango.addView(tvSignal)

        // ── Prediction Grid Row 1 ───────────────────────────────────────
        val grid1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 4, 0, 0) }
        tvNextPred = miniBox(ctx, grid1, "NEXT", "–", "#64B5F6", 1f)
        tvCashout = miniBox(ctx, grid1, "CASHOUT", "–", "#00FF88", 1f)
        tvMinCashout = miniBox(ctx, grid1, "MIN OUT", "–", "#FFD740", 1f)
        rango.addView(grid1)

        // ── Prediction Grid Row 2 ───────────────────────────────────────
        val grid2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 4, 0, 4) }
        tvBet = miniBox(ctx, grid2, "BET", "–", "#CE93D8", 1f)
        tvTrend = miniBox(ctx, grid2, "TREND", "→ FLAT", "#FFAB40", 1f)
        tvStreak = miniBox(ctx, grid2, "STREAK", "–", "#80DEEA", 1f)
        rango.addView(grid2)

        // ── Reasoning line ──────────────────────────────────────────────
        tvReasoning = TextView(ctx).apply {
            text = "Add rounds to see AI strategy advice"
            setTextColor(Color.WHITE); textSize = 10f
            setBackgroundColor(Color.parseColor("#15FFFFFF"))
            setPadding(8, 6, 8, 6)
        }
        rango.addView(tvReasoning)
        rango.addView(div(ctx))

        // ── Balance ─────────────────────────────────────────────────────
        val balRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 4, 0, 2) }
        balRow.addView(label(ctx, "BALANCE:", "#AAAAAA", 11f, false, 1f))
        tvBalance = TextView(ctx).apply {
            text = "PKR ${"%.0f".format(balance)}"
            setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        }
        balRow.addView(tvBalance)
        rango.addView(balRow)

        // ── Balance buttons ─────────────────────────────────────────────
        val balBtns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 2, 0, 4) }
        listOf("-50" to -50f, "-10" to -10f, "+10" to 10f, "+50" to 50f).forEach { (lbl, amt) ->
            val c = if (amt < 0) "#FF5252" else "#69F0AE"
            val btn = TextView(ctx).apply {
                text = lbl; setTextColor(Color.parseColor(c))
                setBackgroundColor(Color.parseColor("#22FFFFFF"))
                setPadding(14, 5, 14, 5); textSize = 10f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = 6 }
                setOnClickListener {
                    balance = (balance + amt).coerceAtLeast(0f)
                    tvBalance?.text = "PKR ${"%.0f".format(balance)}"
                    scope.launch { prefsManager.saveBalance(balance) }
                    refreshUI()
                }
            }
            balBtns.addView(btn)
        }
        rango.addView(balBtns)

        // ── Risk & Base Bet row ─────────────────────────────────────────
        val riskRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        riskRow.addView(label(ctx, "RISK: ", "#AAAAAA", 10f, false, null))
        tvRisk = TextView(ctx).apply {
            text = "CALCULATING"
            setTextColor(Color.parseColor("#00FF88"))
            textSize = 10f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        riskRow.addView(tvRisk)
        rango.addView(riskRow)
        rango.addView(div(ctx))

        // ── Ribbon (last 5 multipliers) ─────────────────────────────────
        val ribbonRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 4, 0, 4) }
        ribbonRow.addView(label(ctx, "LAST: ", "#AAAAAA", 10f, false, null))
        tvRibbon = TextView(ctx).apply {
            text = "– – – – –"
            setTextColor(Color.WHITE); textSize = 10f; typeface = Typeface.DEFAULT_BOLD
        }
        ribbonRow.addView(tvRibbon)
        rango.addView(ribbonRow)
        rango.addView(div(ctx))

        // ── OCR Controls Header ─────────────────────────────────────────
        rango.addView(label(ctx, "⚡ LIVE SCANNER", "#00FF88", 11f, true, null).apply { setPadding(0, 6, 0, 4) })

        // ── Tab Buttons ─────────────────────────────────────────────────
        val tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, 6) }
        btnAutoTab = TextView(ctx).apply {
            text = "⚡ AUTO OCR"; setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#00FF88"))
            setPadding(14, 7, 14, 7); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
            setOnClickListener { switchTab("AUTO") }
        }
        btnManualTab = TextView(ctx).apply {
            text = "✏ MANUAL"; setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#33FFFFFF"))
            setPadding(14, 7, 14, 7); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { switchTab("MANUAL") }
        }
        tabRow.addView(btnAutoTab); tabRow.addView(btnManualTab)
        rango.addView(tabRow)

        // ── AUTO Layout ─────────────────────────────────────────────────
        layoutAuto = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        btnAutoOcr = Button(ctx).apply {
            text = "▶ START AUTO OCR"
            setBackgroundColor(Color.parseColor("#00C853"))
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { toggleOcr() }
        }
        layoutAuto?.addView(btnAutoOcr)
        tvOcrStatus = TextView(ctx).apply {
            text = "OCR offline. Press START."
            setTextColor(Color.LTGRAY); textSize = 10f; setPadding(0, 4, 0, 0)
        }
        layoutAuto?.addView(tvOcrStatus)
        rango.addView(layoutAuto)

        // ── MANUAL Layout ───────────────────────────────────────────────
        layoutManual = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        layoutManual?.addView(label(ctx, "Game ka multiplier enter karo (e.g. 1.85):", "#AAAAAA", 10f, false, null).apply { setPadding(0, 4, 0, 4) })
        etManualInput = EditText(ctx).apply {
            hint = "e.g. 1.85"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#33FFFFFF"))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 16f; setPadding(16, 10, 16, 10)
        }
        layoutManual?.addView(etManualInput)
        val btnSubmit = Button(ctx).apply {
            text = "✓ SUBMIT & PREDICT"
            setBackgroundColor(Color.parseColor("#2979FF"))
            setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 6 }
            setOnClickListener { submitManualEntry() }
        }
        layoutManual?.addView(btnSubmit)
        rango.addView(layoutManual)
        rango.addView(div(ctx))
        root.addView(layoutRango)

        // ── DRAGON TIGER LAYOUT (hidden in RANGO mode) ──────────────────
        layoutDT = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val dt = layoutDT!!

        // Suggestion banner
        tvDtSuggestion = TextView(ctx).apply {
            text = "🐉 DRAGON TIGER"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 4)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        dt.addView(tvDtSuggestion)

        // Confidence + Pattern row
        val dtInfoRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 2, 0, 6) }
        tvDtConfidence = TextView(ctx).apply {
            text = "Confidence: –"
            setTextColor(Color.LTGRAY); textSize = 10f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            gravity = Gravity.CENTER
        }
        tvDtPattern = TextView(ctx).apply {
            text = "Pattern: –"
            setTextColor(Color.parseColor("#FFD740")); textSize = 10f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            gravity = Gravity.CENTER
        }
        dtInfoRow.addView(tvDtConfidence); dtInfoRow.addView(tvDtPattern)
        dt.addView(dtInfoRow)
        dt.addView(div(ctx))

        // Last 10 history
        val dtHistRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 4, 0, 4) }
        dtHistRow.addView(label(ctx, "LAST: ", "#AAAAAA", 10f, false, null))
        tvDtHistory = TextView(ctx).apply {
            text = "– – – – –"
            setTextColor(Color.WHITE); textSize = 10f; typeface = Typeface.DEFAULT_BOLD
        }
        dtHistRow.addView(tvDtHistory)
        dt.addView(dtHistRow)
        dt.addView(div(ctx))

        // Reasoning
        tvDtReasoning = TextView(ctx).apply {
            text = "Dragon, Tiger ya Tie button dabao."
            setTextColor(Color.WHITE); textSize = 10f
            setBackgroundColor(Color.parseColor("#15FFFFFF"))
            setPadding(8, 6, 8, 6)
        }
        dt.addView(tvDtReasoning)
        dt.addView(div(ctx))

        // Input buttons: DRAGON | TIGER | TIE
        dt.addView(label(ctx, "RESULT ENTER KARO:", "#AAAAAA", 10f, false, null).apply { setPadding(0, 6, 0, 4) })
        val dtBtnRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, 4) }
        val btnDragon = Button(ctx).apply {
            text = "🐉 DRAGON"
            setBackgroundColor(Color.parseColor("#C62828"))
            setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
            setOnClickListener { addDtResult(DtResult.DRAGON) }
        }
        val btnTiger = Button(ctx).apply {
            text = "🐯 TIGER"
            setBackgroundColor(Color.parseColor("#1565C0"))
            setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
            setOnClickListener { addDtResult(DtResult.TIGER) }
        }
        val btnTie = Button(ctx).apply {
            text = "🤝 TIE"
            setBackgroundColor(Color.parseColor("#2E7D32"))
            setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { addDtResult(DtResult.TIE) }
        }
        dtBtnRow.addView(btnDragon); dtBtnRow.addView(btnTiger); dtBtnRow.addView(btnTie)
        dt.addView(dtBtnRow)

        // Undo / Reset row
        val dtCtrlRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 2, 0, 4) }
        val btnUndo = TextView(ctx).apply {
            text = "↩ UNDO"
            setTextColor(Color.parseColor("#FFD740"))
            setBackgroundColor(Color.parseColor("#22FFFFFF"))
            setPadding(16, 6, 16, 6); textSize = 10f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            setOnClickListener {
                if (dtResults.isNotEmpty()) { dtResults.removeAt(0); saveDtHistory(); updateDtUI() }
            }
        }
        val btnReset = TextView(ctx).apply {
            text = "🗑 RESET"
            setTextColor(Color.parseColor("#FF5252"))
            setBackgroundColor(Color.parseColor("#22FFFFFF"))
            setPadding(16, 6, 16, 6); textSize = 10f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                dtResults.clear()
                saveDtHistory()   // full clear from storage too
                updateDtUI()
            }
        }
        dtCtrlRow.addView(btnUndo); dtCtrlRow.addView(btnReset)
        dt.addView(dtCtrlRow)
        root.addView(layoutDT)

        // ── Gemini AI Result ────────────────────────────────────────────
        val geminiHeader = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 6, 0, 4)
        }
        geminiHeader.addView(label(ctx, "🔮 GEMINI AI RESPONSE", "#FFD740", 11f, true, 1f))

        // Refresh button to bypass 4s cooldown
        btnRefreshGemini = TextView(ctx).apply {
            text = "↻"
            setTextColor(Color.parseColor("#FFD740"))
            textSize = 16f
            setPadding(10, 0, 4, 0)
            setOnClickListener { forceGeminiRefresh() }
        }
        geminiHeader.addView(btnRefreshGemini)
        root.addView(geminiHeader)

        // Cooldown timer label
        tvCooldownTimer = TextView(ctx).apply {
            text = ""
            setTextColor(Color.parseColor("#888888"))
            textSize = 9f
            setPadding(0, 0, 0, 2)
            visibility = View.GONE
        }
        root.addView(tvCooldownTimer)

        tvGeminiResult = TextView(ctx).apply {
            text = "Rounds add karo → auto analysis shuru ho"
            setTextColor(Color.WHITE); textSize = 10f
            setBackgroundColor(Color.parseColor("#0A1628"))
            setPadding(10, 8, 10, 8)
        }
        root.addView(tvGeminiResult)

        return root
    }

    // ─── HELPERS ────────────────────────────────────────────────────────────

    private fun label(ctx: Context, text: String, color: String, size: Float, bold: Boolean, weight: Float?): TextView {
        return TextView(ctx).apply {
            this.text = text
            setTextColor(Color.parseColor(color))
            textSize = size
            if (bold) typeface = Typeface.DEFAULT_BOLD
            weight?.let {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, it)
            }
        }
    }

    private fun closeBtn(ctx: Context) = TextView(ctx).apply {
        text = "✕"; setTextColor(Color.WHITE); textSize = 16f
        setPadding(12, 0, 0, 0)
        setOnClickListener { stopHud(); stopSelf() }
    }

    private fun div(ctx: Context) = View(ctx).apply {
        setBackgroundColor(Color.parseColor("#33FFFFFF"))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply {
            topMargin = 4; bottomMargin = 4
        }
    }

    private fun miniBox(ctx: Context, parent: LinearLayout, label: String, default: String, color: String, weight: Float): TextView {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("${color}22".replace("#", "#")))
            setPadding(8, 6, 8, 6)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight).apply { marginEnd = 4 }
        }
        box.addView(TextView(ctx).apply {
            text = label; setTextColor(Color.LTGRAY); textSize = 8f; gravity = Gravity.CENTER
        })
        val tv = TextView(ctx).apply {
            text = default; setTextColor(Color.parseColor(color))
            textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        box.addView(tv)
        parent.addView(box)
        return tv
    }

    // ─── GAME MODE SWITCHING ─────────────────────────────────────────────────

    private fun switchGameMode(mode: String) {
        gameMode = mode
        if (mode == "RANGO") {
            layoutRango?.visibility = View.VISIBLE
            layoutDT?.visibility = View.GONE
            btnGameRango?.setBackgroundColor(Color.parseColor("#00FF88")); btnGameRango?.setTextColor(Color.BLACK)
            btnGameDT?.setBackgroundColor(Color.parseColor("#33FFFFFF")); btnGameDT?.setTextColor(Color.WHITE)
        } else {
            layoutRango?.visibility = View.GONE
            layoutDT?.visibility = View.VISIBLE
            btnGameDT?.setBackgroundColor(Color.parseColor("#FFD740")); btnGameDT?.setTextColor(Color.BLACK)
            btnGameRango?.setBackgroundColor(Color.parseColor("#33FFFFFF")); btnGameRango?.setTextColor(Color.WHITE)
            updateDtUI()
        }
    }

    // ─── DRAGON TIGER ────────────────────────────────────────────────────────

    private fun addDtResult(result: DtResult) {
        dtResults.add(0, result)           // newest at front — unlimited, no cap
        saveDtHistory()
        updateDtUI()
    }

    // ── Persist DT history to SharedPreferences ───────────────────────────────
    // Format: comma-separated chars "D", "T", "=" — simple and fast
    private fun saveDtHistory() {
        val encoded = dtResults.joinToString(",") { r ->
            when (r) { DtResult.DRAGON -> "D"; DtResult.TIGER -> "T"; DtResult.TIE -> "=" }
        }
        getSharedPreferences(DT_PREFS, Context.MODE_PRIVATE).edit()
            .putString(DT_PREFS_KEY, encoded).apply()
    }

    private fun loadDtHistory() {
        val encoded = getSharedPreferences(DT_PREFS, Context.MODE_PRIVATE)
            .getString(DT_PREFS_KEY, "") ?: ""
        if (encoded.isEmpty()) return
        dtResults.clear()
        encoded.split(",").forEach { ch ->
            when (ch) {
                "D" -> dtResults.add(DtResult.DRAGON)
                "T" -> dtResults.add(DtResult.TIGER)
                "=" -> dtResults.add(DtResult.TIE)
            }
        }
    }

    private fun updateDtUI() {
        val pred = DragonTigerEngine.analyze(dtResults)

        // Suggestion — big colored text
        val suggText = when (pred.suggestion) {
            "DRAGON" -> "🐉 BET: DRAGON"
            "TIGER"  -> "🐯 BET: TIGER"
            "TIE"    -> "🤝 BET: TIE"
            "SKIP"   -> "⚠ SKIP THIS ROUND"
            else     -> "🐉 DRAGON TIGER"
        }
        tvDtSuggestion?.text = suggText
        tvDtSuggestion?.setTextColor(pred.suggestionColor.toInt())

        tvDtPattern?.text = pred.patternLabel
        tvDtPattern?.setTextColor(pred.patternColor.toInt())
        tvDtConfidence?.text = "Confidence: ${pred.confidence}%"
        tvDtReasoning?.text = pred.reasoning

        // History badges: D=red, T=blue, TIE=green
        val histStr = if (pred.lastResults.isEmpty()) "– – – – –"
        else pred.lastResults.joinToString("  ") { r ->
            when (r) {
                DtResult.DRAGON -> "D"
                DtResult.TIGER  -> "T"
                DtResult.TIE    -> "="
            }
        }
        tvDtHistory?.text = histStr
    }

    // ─── TAB SWITCHING ───────────────────────────────────────────────────────

    private fun switchTab(mode: String) {
        if (mode == "AUTO") {
            layoutAuto?.visibility = View.VISIBLE
            layoutManual?.visibility = View.GONE
            btnAutoTab?.setBackgroundColor(Color.parseColor("#00FF88")); btnAutoTab?.setTextColor(Color.BLACK)
            btnManualTab?.setBackgroundColor(Color.parseColor("#33FFFFFF")); btnManualTab?.setTextColor(Color.WHITE)
            setFlags(
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            )
        } else {
            layoutAuto?.visibility = View.GONE
            layoutManual?.visibility = View.VISIBLE
            btnManualTab?.setBackgroundColor(Color.parseColor("#00FF88")); btnManualTab?.setTextColor(Color.BLACK)
            btnAutoTab?.setBackgroundColor(Color.parseColor("#33FFFFFF")); btnAutoTab?.setTextColor(Color.WHITE)
            setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL)
        }
    }

    private fun setFlags(flags: Int) {
        val params = hudView?.layoutParams as? WindowManager.LayoutParams ?: return
        params.flags = flags
        runCatching { windowManager.updateViewLayout(hudView, params) }
    }

    // ─── OCR TOGGLE ─────────────────────────────────────────────────────────

    private fun toggleOcr() {
        if (isOcrRunning) {
            ocrManager?.stop(); isOcrRunning = false
            btnAutoOcr?.text = "▶ START AUTO OCR"
            btnAutoOcr?.setBackgroundColor(Color.parseColor("#00C853"))
            tvOcrStatus?.text = "OCR stopped."
        } else {
            if (resultCode != 0 && resultData != null) {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val projection = mgr.getMediaProjection(resultCode, resultData!!)

                // ── Provide HUD bounds so OCR can mask our widget ────────
                ocrManager?.getOverlayBounds = { getHudBoundsOnScreen() }

                ocrManager?.onMultiplierDetected = { v ->
                    Handler(Looper.getMainLooper()).post { onRoundCaptured(v, "AUTO") }
                }
                ocrManager?.onStatusChange = { s ->
                    Handler(Looper.getMainLooper()).post { tvOcrStatus?.text = s }
                }
                ocrManager?.start(projection); isOcrRunning = true
                btnAutoOcr?.text = "⏹ STOP OCR"
                btnAutoOcr?.setBackgroundColor(Color.parseColor("#FF5252"))
                tvOcrStatus?.text = "Scanning..."
            } else {
                tvOcrStatus?.text = "⚠ Auth needed. Open main app → AUTH OCR first."
                tvOcrStatus?.setTextColor(Color.parseColor("#FFD740"))
            }
        }
    }

    // Returns the HUD widget's screen-coordinates bounding Rect for masking
    private fun getHudBoundsOnScreen(): Rect? {
        val view = hudView ?: return null
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)
        val w = view.width
        val h = view.height
        if (w == 0 || h == 0) return null
        return Rect(loc[0], loc[1], loc[0] + w, loc[1] + h)
    }

    // ─── MANUAL SUBMIT ───────────────────────────────────────────────────────

    private fun submitManualEntry() {
        val input = etManualInput?.text?.toString()?.trim() ?: return
        val value = input.toFloatOrNull()
        if (value == null || value <= 0f) {
            etManualInput?.error = "Valid number enter karo"
            return
        }
        etManualInput?.text?.clear()
        onRoundCaptured(value, "MANUAL")
    }

    // ─── CORE LOGIC: Round captured → update everything ──────────────────────

    private fun onRoundCaptured(value: Float, source: String) {
        tvOcrStatus?.text = "Got: ${"%.2f".format(value)}x — Analyzing..."

        scope.launch {
            db.roundDao().insertRound(RoundEntity(multiplier = value, source = source))
            val recent = db.roundDao().getRecentRounds(20)

            // ── Local prediction engine (instant, offline) ──────────────
            val pred = PredictionEngine.predict(recent)
            val sigColor = pred.signalColor.toInt()

            tvSignal?.text = pred.signal; tvSignal?.setTextColor(sigColor)
            tvNextPred?.text = "${"%.2f".format(pred.nextMultiplier)}x"; tvNextPred?.setTextColor(sigColor)
            tvCashout?.text = "${"%.1f".format(pred.cashoutTarget)}x"
            tvMinCashout?.text = "${"%.1f".format(pred.minCashout)}x"
            tvBet?.text = "${"%.1f".format(pred.betMultiplier)}x base"
            tvTrend?.text = pred.trend
            tvStreak?.text = pred.streakType
            tvReasoning?.text = pred.reasoning

            // ── Bankroll ────────────────────────────────────────────────
            val bankroll = BankrollCalculator.calculate(balance, recent.map { it.multiplier })
            tvRisk?.text = "${bankroll.riskLabel} | Bet: PKR ${"%.0f".format(bankroll.baseBet)}"
            tvRisk?.setTextColor(bankroll.riskColor.toInt())

            // ── Ribbon: last 5 multipliers ──────────────────────────────
            val ribbonText = recent.take(5).joinToString("  ") { "${"%.1f".format(it.multiplier)}x" }
            tvRibbon?.text = ribbonText

            // ── Gemini AI — 4-second cooldown guard ─────────────────────
            if (apiKey.isNotBlank()) {
                val now = System.currentTimeMillis()
                val elapsed = now - lastGeminiCallTime
                if (elapsed >= GEMINI_COOLDOWN_MS) {
                    callGemini(recent, bankroll.baseBet)
                } else {
                    val remaining = ((GEMINI_COOLDOWN_MS - elapsed) / 1000).toInt()
                    tvCooldownTimer?.text = "⏳ Next Gemini call in ${remaining}s  (↻ to refresh now)"
                    tvCooldownTimer?.visibility = View.VISIBLE
                }
            } else {
                tvGeminiResult?.text = "API key nahi. Gemini tab mein add karo."
                tvCooldownTimer?.visibility = View.GONE
            }
        }
    }

    // ── Call Gemini and update result ────────────────────────────────────────
    private fun callGemini(recent: List<com.rango.companion.data.RoundEntity>, baseBet: Float) {
        lastGeminiCallTime = System.currentTimeMillis()
        tvGeminiResult?.text = "🔮 Gemini analyzing..."
        tvCooldownTimer?.visibility = View.GONE
        scope.launch {
            val aiResult = geminiRepo.quickPrediction(apiKey, recent.first().multiplier, recent, balance)
            tvGeminiResult?.text = aiResult
        }
    }

    // ── Refresh button: bypass 4s cooldown ──────────────────────────────────
    private fun forceGeminiRefresh() {
        if (apiKey.isBlank()) {
            tvGeminiResult?.text = "API key nahi. Gemini tab mein add karo."
            return
        }
        scope.launch {
            val recent = db.roundDao().getRecentRounds(20)
            if (recent.isEmpty()) {
                tvGeminiResult?.text = "Pehle kuch rounds add karo."
                return@launch
            }
            val bankroll = BankrollCalculator.calculate(balance, recent.map { it.multiplier })
            callGemini(recent, bankroll.baseBet)
        }
    }

    // ─── REFRESH UI (balance changed etc.) ──────────────────────────────────

    private fun refreshUI() {
        scope.launch {
            val recent = db.roundDao().getRecentRounds(20)
            val bankroll = BankrollCalculator.calculate(balance, recent.map { it.multiplier })
            tvBalance?.text = "PKR ${"%.0f".format(balance)}"
            tvRisk?.text = "${bankroll.riskLabel} | Bet: PKR ${"%.0f".format(bankroll.baseBet)}"
            tvRisk?.setTextColor(bankroll.riskColor.toInt())
            val ribbonText = recent.take(5).joinToString("  ") { "${"%.1f".format(it.multiplier)}x" }
            tvRibbon?.text = if (ribbonText.isEmpty()) "– – – – –" else ribbonText
            if (recent.isNotEmpty()) {
                val pred = PredictionEngine.predict(recent)
                tvSignal?.text = pred.signal; tvSignal?.setTextColor(pred.signalColor.toInt())
                tvNextPred?.text = "${"%.2f".format(pred.nextMultiplier)}x"
                tvCashout?.text = "${"%.1f".format(pred.cashoutTarget)}x"
                tvMinCashout?.text = "${"%.1f".format(pred.minCashout)}x"
                tvBet?.text = "${"%.1f".format(pred.betMultiplier)}x base"
                tvTrend?.text = pred.trend; tvStreak?.text = pred.streakType
                tvReasoning?.text = pred.reasoning
            }
        }
    }

    // ─── DRAG ────────────────────────────────────────────────────────────────

    private fun setupDrag(view: View, params: WindowManager.LayoutParams) {
        var iX = 0; var iY = 0; var iTX = 0f; var iTY = 0f; var dragging = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { iX = params.x; iY = params.y; iTX = e.rawX; iTY = e.rawY; dragging = false; false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - iTX) > 10 || Math.abs(e.rawY - iTY) > 10) {
                        dragging = true; params.x = iX + (e.rawX - iTX).toInt(); params.y = iY + (e.rawY - iTY).toInt()
                        runCatching { windowManager.updateViewLayout(view, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> dragging
                else -> false
            }
        }
    }

    // ─── NOTIFICATION ────────────────────────────────────────────────────────

    private fun buildNotification(): Notification {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        val pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("⬡ Rango Pilot HUD Active")
            .setContentText("Floating HUD running • Tap to open app")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Rango HUD", NotificationManager.IMPORTANCE_LOW)
            .apply { description = "Floating HUD overlay" }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    // ─── CLEANUP ─────────────────────────────────────────────────────────────

    private fun stopHud() {
        ocrManager?.stop()
        hudView?.let { runCatching { windowManager.removeView(it) } }
        hudView = null
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        super.onDestroy()
        stopHud(); scope.cancel()
    }
}
