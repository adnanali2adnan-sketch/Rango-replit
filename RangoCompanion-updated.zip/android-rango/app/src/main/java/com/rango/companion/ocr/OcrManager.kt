package com.rango.companion.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper

class OcrManager(private val context: Context) {

    enum class GamePhase { BETTING, FLYING, CRASHED }

    private val recognizer = com.google.mlkit.vision.text.TextRecognition.getClient(
        com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS
    )
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var isRunning = false
    private val handler = Handler(Looper.getMainLooper())

    private var phase = GamePhase.BETTING
    private var peakFlyingValue = 1.00f
    private var lastLoggedValue = 0f
    private var roundLogged = false

    // Virtual display target dimensions — portrait 480×800, landscape 800×480
    private var vdW = 480
    private var vdH = 800
    private var lastOrientation = -1

    var onMultiplierDetected: ((Float) -> Unit)? = null
    var onStatusChange: ((String) -> Unit)? = null

    // FloatingHudService sets this so OCR can mask the HUD widget area
    var getOverlayBounds: (() -> Rect?)? = null

    fun start(projection: MediaProjection) {
        if (isRunning) return
        mediaProjection = projection
        isRunning = true
        phase = GamePhase.BETTING
        roundLogged = false
        peakFlyingValue = 1.00f

        val metrics = context.resources.displayMetrics
        lastOrientation = context.resources.configuration.orientation
        // Portrait → 480×800, Landscape → 800×480
        if (metrics.widthPixels > metrics.heightPixels) {
            vdW = 800; vdH = 480
        } else {
            vdW = 480; vdH = 800
        }

        setupVirtualDisplay()
        onStatusChange?.invoke("OCR Active — Watching screen...")
        scheduleScan()
    }

    private fun setupVirtualDisplay() {
        virtualDisplay?.release()
        imageReader?.close()
        imageReader = ImageReader.newInstance(vdW, vdH, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "RangoOCR", vdW, vdH, context.resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, handler
        )
    }

    fun stop() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay = null; imageReader = null; mediaProjection = null
        onStatusChange?.invoke("OCR Stopped")
    }

    fun isActive() = isRunning

    private fun scheduleScan() {
        if (!isRunning) return
        // 1.5 seconds per scan as per architecture spec
        handler.postDelayed({
            checkOrientationChange()
            captureAndProcess()
            scheduleScan()
        }, 1500)
    }

    private fun checkOrientationChange() {
        val newOrientation = context.resources.configuration.orientation
        if (newOrientation != lastOrientation) {
            lastOrientation = newOrientation
            val metrics = context.resources.displayMetrics
            if (metrics.widthPixels > metrics.heightPixels) {
                vdW = 800; vdH = 480
            } else {
                vdW = 480; vdH = 800
            }
            setupVirtualDisplay()
            onStatusChange?.invoke("Orientation changed — display reset")
        }
    }

    private fun captureAndProcess() {
        var image: Image? = null
        try {
            image = imageReader?.acquireLatestImage() ?: return

            val plane   = image.planes[0]
            val buffer  = plane.buffer
            val pStride = plane.pixelStride
            val rStride = plane.rowStride
            val w = image.width
            val h = image.height

            // Convert RGBA (ImageReader) → ARGB_8888 (ML Kit requirement)
            val rowWidth = rStride / pStride
            val rawBmp = Bitmap.createBitmap(rowWidth, h, Bitmap.Config.ARGB_8888)
            rawBmp.copyPixelsFromBuffer(buffer)
            val fullBmp = if (rowWidth != w) {
                val c = Bitmap.createBitmap(rawBmp, 0, 0, w, h)
                rawBmp.recycle(); c
            } else rawBmp

            // ─── OVERLAY MASKING: Draw black box over HUD position ──────────
            // This prevents OCR reading our own widget's prediction numbers
            val overlayBounds = getOverlayBounds?.invoke()
            if (overlayBounds != null) {
                val physW = context.resources.displayMetrics.widthPixels.toFloat()
                val physH = context.resources.displayMetrics.heightPixels.toFloat()
                val scaleX = w / physW
                val scaleY = h / physH
                val overlayL = (overlayBounds.left   * scaleX)
                val overlayT = (overlayBounds.top    * scaleY)
                val overlayR = (overlayBounds.right  * scaleX)
                val overlayB = (overlayBounds.bottom * scaleY)
                val canvas = Canvas(fullBmp)
                val paint = Paint().apply {
                    color = Color.BLACK
                    style = Paint.Style.FILL
                }
                canvas.drawRect(overlayL, overlayT, overlayR, overlayB, paint)
            }

            // ─── SMART CROPPING: Skip negative space, scan only game area ──
            // Width:  skip left 3%, use 94% of width
            // Height: top 2% to 48% (covers multiplier + history ribbon)
            val cropLeft = (w * 0.03f).toInt()
            val cropW    = (w * 0.94f).toInt().coerceAtMost(w - cropLeft)
            val scanTop  = (h * 0.02f).toInt()
            val scanH    = (h * 0.46f).toInt().coerceAtMost(h - scanTop)

            // Ribbon: very top area 2%–10%
            val ribTop = scanTop
            val ribH   = (h * 0.08f).toInt().coerceAtMost(h - ribTop)

            // Main multiplier area: 10%–48%
            val mainTop = (h * 0.10f).toInt()
            val mainH   = (h * 0.38f).toInt().coerceAtMost(h - mainTop)

            val mainBmp = Bitmap.createBitmap(fullBmp, cropLeft, mainTop, cropW, mainH)
            val ribBmp  = Bitmap.createBitmap(fullBmp, cropLeft, ribTop,  cropW, ribH)
            fullBmp.recycle()

            processFrame(mainBmp, ribBmp)
        } catch (e: OutOfMemoryError) {
            onStatusChange?.invoke("Low memory — scan paused")
        } catch (_: Exception) {
        } finally {
            image?.close()
        }
    }

    private fun processFrame(mainBmp: Bitmap, ribBmp: Bitmap) {
        val mainImg = com.google.mlkit.vision.common.InputImage.fromBitmap(mainBmp, 0)

        recognizer.process(mainImg)
            .addOnSuccessListener { visionText ->
                mainBmp.recycle()
                val allText = visionText.text.uppercase()

                // Betting phase keywords
                val isBetting = allText.contains("GETTING") ||
                                allText.contains("THE BETS") ||
                                allText.contains("NEXT ROUND")

                // Crash event keywords (per architecture spec)
                val isCrashed = allText.contains("FLEW AWAY") ||
                                (allText.contains("FLEW") && allText.contains("AWAY")) ||
                                allText.contains("BURST") ||
                                allText.contains("CRASHED")

                // ─── NEW REGEX: matches decimals with optional x suffix ────
                // e.g. "1.85", "12.5x", "1.03", "2,50x"
                val regex = Regex(
                    """\b(\d+[.,]\d{1,2})\s*x?\b""",
                    RegexOption.IGNORE_CASE
                )

                // Find multiplier with LARGEST font — game number is always
                // far bigger than any overlay/popup text
                var bigValue  = 0f
                var bigFontH  = 0

                for (block in visionText.textBlocks) {
                    for (line in block.lines) {
                        val fh = line.boundingBox?.height() ?: 0
                        if (fh < 60) continue
                        regex.findAll(line.text).forEach { m ->
                            val v = m.groupValues[1].replace(",", ".").toFloatOrNull()
                            if (v != null && v in 1.01f..200f && fh > bigFontH) {
                                bigFontH = fh; bigValue = v
                            }
                        }
                    }
                }

                when {
                    // ── BETTING phase ────────────────────────────────────────
                    isBetting -> {
                        if (phase == GamePhase.FLYING && !roundLogged && peakFlyingValue > 1.01f) {
                            roundLogged = true
                            lastLoggedValue = peakFlyingValue
                            onStatusChange?.invoke("💥 Round: ${"%.2f".format(peakFlyingValue)}x (auto-logged)")
                            onMultiplierDetected?.invoke(peakFlyingValue)
                        }
                        if (phase != GamePhase.BETTING) {
                            phase = GamePhase.BETTING
                            peakFlyingValue = 1.00f
                            onStatusChange?.invoke("⏳ Betting — place your bet!")
                        }
                        roundLogged = false
                        processRibbon(ribBmp)
                    }

                    // ── CRASHED ───────────────────────────────────────────────
                    isCrashed -> {
                        ribBmp.recycle()
                        if (!roundLogged) {
                            val final = when {
                                bigValue > 1.00f && bigFontH >= 80 -> bigValue
                                peakFlyingValue > 1.00f            -> peakFlyingValue
                                bigValue > 1.00f                   -> bigValue
                                else                               -> 0f
                            }
                            if (final > 1.00f) {
                                roundLogged = true
                                lastLoggedValue = final
                                phase = GamePhase.CRASHED
                                onStatusChange?.invoke("💥 CRASHED ${"%.2f".format(final)}x ✓ Logged!")
                                onMultiplierDetected?.invoke(final)
                            }
                        } else {
                            onStatusChange?.invoke("Crashed (${"%.2f".format(lastLoggedValue)}x) — next...")
                        }
                    }

                    // ── FLYING — track PEAK ───────────────────────────────────
                    bigValue > 1.00f && bigFontH >= 60 -> {
                        ribBmp.recycle()
                        phase = GamePhase.FLYING
                        if (bigValue > peakFlyingValue) peakFlyingValue = bigValue
                        onStatusChange?.invoke("🛩 Flying: ${"%.2f".format(bigValue)}x")
                    }

                    else -> {
                        ribBmp.recycle()
                        if (phase == GamePhase.FLYING)
                            onStatusChange?.invoke("🔍 Scanning... (peak ${"%.2f".format(peakFlyingValue)}x)")
                    }
                }
            }
            .addOnFailureListener { e ->
                mainBmp.recycle()
                ribBmp.recycle()
                onStatusChange?.invoke("Scan err: ${e.message?.take(30) ?: "ML Kit"}")
            }
    }

    private fun processRibbon(ribBmp: Bitmap) {
        val img = com.google.mlkit.vision.common.InputImage.fromBitmap(ribBmp, 0)
        val re = Regex("""\b(\d+[.,]\d{1,2})\s*x?\b""", RegexOption.IGNORE_CASE)
        recognizer.process(img)
            .addOnSuccessListener { text ->
                ribBmp.recycle()
                val vals = mutableListOf<Float>()
                for (block in text.textBlocks) {
                    for (line in block.lines) {
                        re.findAll(line.text).forEach { m ->
                            m.groupValues[1].replace(",", ".").toFloatOrNull()
                                ?.takeIf { it in 1.01f..200f }
                                ?.let { vals.add(it) }
                        }
                    }
                }
                if (vals.size >= 2)
                    onStatusChange?.invoke("Ribbon: ${vals.take(5).joinToString(" | ") { "${"%.2f".format(it)}x" }}")
            }
            .addOnFailureListener { ribBmp.recycle() }
    }
}
